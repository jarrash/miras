# Handoff: MIRAS Newsletter Section

## Overview
A new **newsletter signup section** for the MIRAS (مِراس) podcast website. It lets visitors
subscribe by email to receive new episodes, guest highlights, and resilience insights. The section
is a two-column block: marketing copy + signup form on one side, a podcast photo on the other.

This is a **new section to be added** to the existing single-page MIRAS site. It does **not** replace
any current section. Insert it as a new block in the existing page flow (recommended placement:
between the "Platforms / منصات الاستماع" section (S09) and the "Final CTA" section (S10), or
immediately before the footer).

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype showing the intended
look and behavior, not production code to copy verbatim. The task is to **recreate this design inside
the existing MIRAS website codebase**, reusing its established components, tokens, fonts, and patterns.
The MIRAS site in this project is authored as a "Design Component" (`.dc.html`) prototype; in the real
codebase, implement the section using whatever framework/structure that codebase already uses
(React/Vue/Astro/plain HTML, etc.), matching the conventions of the surrounding sections.

**Do not** change existing routes, content, integrations, functionality, or responsiveness. Only **add**
this section and the small, additive styles it needs.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, and interactions are specified below and
should be matched precisely, using the site's existing design tokens and fonts.

---

## What must change (scope)

### Pages
- **MIRAS home page** (the single-page site — `MIRAS Podcast.dc.html` in this project). This is the only
  page affected.

### Sections
- **ADD: Newsletter section** (new block). No existing section's content or markup should be modified,
  beyond inserting this new `<section>` into the page in the chosen position.

### Components (reused from the existing site — do not restyle them)
- **Pill / eyebrow badge** — identical to the hero badge: rounded 100px pill, 1px `rgba(255,255,255,.1)`
  border, mono uppercase label with a 5px blue dot. Reuse the existing pattern.
- **Primary button** — same blue (`#5578FF`) fill button used by the hero "استمع الآن" / final CTA, with
  the same hover treatment. Here it is full-width with a trailing arrow icon.
- **Email text input** — a new control variant (the site has no form input yet). Style it to match the
  dark surface system (see Design Tokens). This is the only genuinely new component.
- **Checkmark feature chips** — small inline label + Lucide-style `check` icon in blue.
- **Section container** — same `max-width` container + horizontal padding rhythm as other sections.

### Images
- **`Miras02.jpg`** (already in the project at `assets/img/Miras02.jpg`) — reused as the section image.
  No new image asset is required. The image gets `border-radius` + a subtle navy gradient overlay and the
  blue dotted-grid motif used elsewhere on the site.

### Styles
- Additive only. New CSS needed:
  - input `::placeholder` color rule
  - a `@media (max-width:880px)` rule to stack the two columns (image below content)
  - `:focus` style on the email input
- All colors, fonts, radii, and shadows come from existing site values — see tokens below. No new color
  or font is introduced.

---

## Screen / View

### Newsletter Section
- **Purpose:** Convert visitors into email subscribers.
- **Layout:**
  - Full-width `<section>`, background `#050505`, vertical padding `120px`, horizontal padding `52px`,
    `min-height` not required (content-height is fine; prototype uses `min-height:100vh` + vertical
    centering, but in-page you can use natural height with `~120px` top/bottom padding).
  - Inner container: `max-width:1280px`, centered (`margin:0 auto`), `width:100%`.
  - **CSS Grid**, `grid-template-columns: 1fr 1fr`, `gap:96px`, `align-items:center`.
  - **Direction:** RTL (`dir="rtl"`), text right-aligned — matches the rest of the site.
  - **Responsive:** at `max-width:880px`, collapse to a single column (`grid-template-columns:1fr`,
    `gap:48px`). **Order:** content column first (`order:1`), image second (`order:2`). On mobile the
    image gets `min-height:320px`.

#### Left column — content (flex column, `align-items:flex-start`, `text-align:right`)
In reading order (top → bottom):

1. **Badge (pill)**
   - `display:inline-flex; align-items:center; gap:9px; padding:7px 18px;`
   - `border:1px solid rgba(255,255,255,.1); border-radius:100px;`
   - Font: IBM Plex Mono, `11px`, `letter-spacing:.14em`, uppercase, color `rgba(247,247,245,.5)`.
   - Leading dot: `5px` circle, `background:#5578FF`.
   - Text: **"النشرة البريدية"**
   - `margin-bottom:28px`

2. **Heading** (`<h2>`)
   - Font: ThmanyahSerifDisplay, weight `700`, `font-size:clamp(34px,4vw,58px)`, `line-height:1.25`,
     color `#F7F7F5`, `text-wrap:pretty`.
   - Text: **"لا تفوّت أي حلقة من مِراس"**
   - `margin-bottom:24px`

3. **Paragraph** (`<p>`)
   - Font: ThmanyahSans, weight `300`, `font-size:17px`, `line-height:2.05`,
     color `rgba(247,247,245,.5)`, `max-width:460px`, `text-wrap:pretty`.
   - Text: **"اشترك في نشرتنا البريدية لتصلك أحدث الحلقات، ومقتطفات من حوارات القادة، ورؤى حول بناء المؤسسات الأكثر مرونة — مباشرة إلى بريدك."**
   - `margin-bottom:44px`

4. **Email input** (`<input type="email">`)
   - `width:100%`, `background:rgba(255,255,255,.04)`, `border:1px solid rgba(255,255,255,.12)`,
     `border-radius:6px`, `padding:16px 20px`.
   - Font: ThmanyahSans, `15px`, color `#F7F7F5`.
   - `outline:none`, transition `border-color .25s, background .25s`.
   - Placeholder text: **"بريدك الإلكتروني"**, placeholder color `rgba(247,247,245,.32)`.
   - **Focus state:** `border-color:#5578FF; background:rgba(85,120,255,.06)`.
   - `margin-bottom:14px`

5. **Subscribe button** (`<button>`)
   - `width:100%`, `display:inline-flex; align-items:center; justify-content:center; gap:10px;`
   - `padding:16px 32px`, `background:#5578FF`, color `#F7F7F5`, `border:none`,
     `border-radius:6px`, `letter-spacing:.02em`, `cursor:pointer`.
   - Font: ThmanyahSans, weight `600`, `15px`.
   - Label: **"اشترك الآن"** + trailing arrow icon (Lucide `arrow-right`, `16px`, mirrored with
     `transform:scaleX(-1)` so it points left for RTL).
   - **Hover:** `background:#6B8FFF; box-shadow:0 8px 40px rgba(85,120,255,.38); transform:translateY(-2px)`.
   - **Press (recommended, to match site):** `transform:translateY(1px)` — optional.
   - `margin-bottom:32px`

6. **Feature chips row** (`display:flex; flex-wrap:wrap; gap:28px; align-items:center`)
   - Three chips, each `display:inline-flex; align-items:center; gap:8px; font-size:13px;`
     color `rgba(247,247,245,.45)`.
   - Each leads with a Lucide `check` icon: `15px`, `stroke:#5578FF`, `stroke-width:2.2`,
     round caps/joins, `flex-shrink:0`.
   - Texts: **"حلقات أسبوعية"**, **"بدون رسائل مزعجة"**, **"إلغاء في أي وقت"**

#### Right column — image
- `position:relative; width:100%; aspect-ratio:5/4; border-radius:14px; overflow:hidden;`
  background `#060810`.
- `<img>` `Miras02.jpg`: absolutely positioned, `width/height:100%`, `object-fit:cover`,
  `object-position:50% 30%`, `filter:contrast(1.04) brightness(.92) saturate(.95)`.
- Overlay 1 (gradient): `linear-gradient(120deg, rgba(6,8,16,.4) 0%, rgba(6,8,16,.05) 55%, rgba(12,13,26,.3) 100%)`.
- Overlay 2 (dotted grid motif — same as elsewhere on site):
  `background-image:radial-gradient(circle, rgba(85,120,255,.16) 1px, transparent 1px); background-size:26px 26px; opacity:.22`.
- Vertically centered relative to the left column via the grid's `align-items:center`.

---

## Interactions & Behavior
- **Submit:** Wire the email input + subscribe button to the site's existing newsletter / mailing-list
  integration if one exists. If none exists yet, implement a standard email submit (POST to the backend
  endpoint of choice) with:
  - **Validation:** required, valid email format. On invalid, show an inline error in the site's voice
    (Arabic, e.g. "يرجى إدخال بريد إلكتروني صحيح").
  - **Loading state:** disable the button + show a subtle pending state while submitting.
  - **Success state:** replace the form (or show a confirmation message) — e.g. "تم الاشتراك بنجاح".
  - **Error state:** inline error message; keep entered value.
- **Hover/focus:** as specified per component above. Keep transitions in the site's range
  (≈120–360ms, ease-out).
- **Reveal-on-scroll:** The site reveals blocks on scroll via `[data-reveal]` + IntersectionObserver
  (opacity 0→1, `translateY(22px)→0`, `cubic-bezier(0.16,1,0.3,1)`, `~0.85s`, optional `data-delay`).
  Add `data-reveal` to the section's children (badge/heading/paragraph/form/image, with staggered
  `data-delay`) so it animates consistently with the rest of the page. Respect `prefers-reduced-motion`.
- **Responsive:** single-column stack at ≤880px (content first, image below), per the layout section.

## State Management
- `email` (string) — controlled input value.
- `status` — one of `idle | submitting | success | error`.
- `errorMessage` (string) — for validation/submit errors.
- Data: a single POST to the newsletter endpoint/integration. No other fetching.

## Design Tokens (all reused from the existing MIRAS site)

**Colors**
- Background (section): `#050505`
- Surface (dark image bg): `#060810`
- Text strong: `#F7F7F5`
- Text muted: `rgba(247,247,245,.5)` / `rgba(247,247,245,.45)`
- Placeholder: `rgba(247,247,245,.32)`
- Accent (blue): `#5578FF`; hover: `#6B8FFF`; tints: `rgba(85,120,255,.06)`, `rgba(85,120,255,.16)`, `rgba(85,120,255,.38)`
- Hairline border: `rgba(255,255,255,.1)` / `rgba(255,255,255,.12)`

**Typography**
- Display/headings: **ThmanyahSerifDisplay** (700 used here)
- Body/UI: **ThmanyahSans** (300 body, 600 button)
- Mono labels/eyebrows: **IBM Plex Mono** (11px, uppercase, `letter-spacing:.14em`)
- Fonts are already loaded in the site via `@font-face` (woff2 in `assets/fonts/`) — reuse them; do not add new fonts.

**Spacing (section-internal)**
- Section padding: `120px` vertical / `52px` horizontal
- Container max-width: `1280px`; grid gap `96px` (desktop) / `48px` (mobile)
- Vertical rhythm: badge `28` → heading `24` → paragraph `44` → input `14` → button `32`

**Radius**
- Controls (input/button): `6px`
- Image: `14px`
- Pill badge / dot: `100px` / `50%`

**Shadow**
- Button hover glow: `0 8px 40px rgba(85,120,255,.38)`

**Icons**
- Lucide style (thin line, rounded caps/joins, ~2px stroke): `check` and `arrow-right`. Inline SVG in the
  prototype; in code, use the site's existing icon approach. The arrow is mirrored (`scaleX(-1)`) for RTL.

## Assets
- **`Miras02.jpg`** — existing project asset (`assets/img/Miras02.jpg`), a copy is included in
  `./assets/` here for reference. No new images needed.

## Files
- **`MIRAS Newsletter.dc.html`** — the newsletter section prototype (the design to recreate).
- **`reference/MIRAS Podcast.dc.html`** — the full existing site, for context on tokens, fonts,
  `data-reveal` animation pattern, nav, existing button/badge styles, and where to insert the section.
- **`assets/Miras02.jpg`** — the section image.
