# Handoff: Joushen "Digital Trust" Article / Content Section

## Overview
A new **editorial content section** for the Joushen website — a long-form article block built on the
Joushen Design System. It pairs a headline band, a full-width hero image, and a two-column article body.
Use it for thought-leadership / insight pages (e.g. "Identity is the new security perimeter").

This is a **new section to be added** to the existing Joushen website. It does **not** replace any
current section.

## About the Design Files
The file in this bundle is a **design reference created in HTML** (a Design Component prototype) — it
shows the intended look and layout, not production code to paste in verbatim. The task is to **recreate
this design inside the existing Joushen website codebase**, reusing the Joushen Design System tokens and
components already in that codebase, matching the conventions of the surrounding pages/sections.

**Do not** change existing routes, content, integrations, functionality, or responsiveness. Only **add**
this section plus the small, additive styles it needs.

## Fidelity
**High-fidelity (hifi).** Colors, typography, spacing, and layout are specified via Joushen Design System
tokens and should be matched precisely using those tokens — not hardcoded values.

---

## Design System (binding)
This section is built entirely on the **Joushen Design System**. Reuse it — do not invent colors, type,
spacing, or components.

- **Tokens** (CSS custom properties): colors, typography, spacing, elevation. Reference `var(--*)`, never
  raw hex. See "Design Tokens used" below for the exact variables this section consumes.
- **Type:** IBM Plex Sans (display/headings/body), IBM Plex Mono (eyebrow/kicker). Already loaded by the
  design system's font tokens.
- **Components:** This section is prose + image, so it uses **tokens only** — there is no Joushen
  component (Button/Card/etc.) that fits a long-form article body. If the host page wraps sections in a
  shared layout/container component, reuse that wrapper. Do not rebuild the article body as Cards.

---

## What must change (scope)

### Pages
- The **Joushen website** (the existing corporate marketing site). Add this section to the relevant
  insight/article page (new or existing). This is the only surface affected.

### Sections
- **ADD: "Digital Trust" article content section** (new block). No existing section is modified.

### Components (reused — do not restyle)
- **Section container / layout wrapper** — reuse the site's existing max-width container
  (`--container-xl` = 1320px) + horizontal padding rhythm.
- **Eyebrow / kicker** — the Joushen mono-uppercase eyebrow pattern (here with a short lime rule before
  the label). Reuse the existing eyebrow treatment if the site has one.
- No new interactive components are introduced.

### Images
- **Hero image** — one full-width image with rounded corners (`16px`), `21/9` aspect ratio,
  `--shadow-md` elevation. In the prototype this is a drag-and-drop `<image-slot>` placeholder so the
  design can be previewed without a real asset; **in production, replace it with a normal responsive
  `<img>`** (or the site's existing image/figure component) pointing at a real photograph. Follow Joushen
  imagery guidance: cool-toned, premium, slightly desaturated — Saudi enterprise, control room, modern
  architecture, or digital infrastructure. No shields/padlocks/hooded-hacker clichés.
  - `reference/image-slot.js` is included **only** to make the prototype previewable — **do not ship it**.

### Styles
- Additive only. New CSS needed:
  - a `@media (max-width:1279px)` rule collapsing the article band to a single column
  - a `@media (max-width:640px)` rule reducing section side padding
  - a `::selection` rule (lime background / navy text) — only if the site doesn't already set one globally
- All colors, fonts, radii, shadows, and spacing come from existing Joushen tokens — see below. No new
  color or font is introduced.

---

## Layout / structure

Full-width `<section>` on the light surface (`--surface-page`), vertical padding ≈`96px`
(`72px` at ≤640px), horizontal padding `52px` (`24px` at ≤640px). Inner container: `max-width:1320px`
(`--container-xl`), centered, `width:100%`. Everything is a single vertical stack:

### 1) Headline band (`<header>`, flex column, `align-items:flex-start`)
1. **Eyebrow** — inline-flex, `gap:10px`. A `18px × 1px` lime rule (`--brand-accent`) followed by the
   label. Font: `--font-mono`, weight 500, `--text-xs` (12px), `letter-spacing:--tracking-wider`
   (0.12em), uppercase, color `--text-muted`. `margin-bottom:20px`. Text: **"Digital Trust"**.
2. **Heading** (`<h1>`) — `--font-display`, weight `--fw-bold` (700),
   `font-size:clamp(34px,4.6vw,60px)`, `line-height:--leading-tight`, `letter-spacing:--tracking-tighter`
   (−0.03em), color `--text-strong`, `text-wrap:balance`, `max-width:18ch`. `margin-bottom:24px`.
   Text: **"Identity is the new security perimeter"**.
3. **Supporting paragraph** (`<p>`) — weight `--fw-regular`, `--text-lg` (18px),
   `line-height:--leading-relaxed` (1.65), color `--text-body`, `max-width:720px`, `text-wrap:pretty`.
   Left-aligned with the heading. Copy: the intro paragraph (see prototype).
   - `header` `margin-bottom:48px`.

### 2) Hero image
- Full-width, `aspect-ratio:21/9`, `border-radius:16px`, `box-shadow:--shadow-md`, `display:block`.
- Production: real `<img>` with `object-fit:cover`, descriptive `alt`. Lazy-load as the site does.

### 3) Article band (`.jsh-article-band`)
- **CSS Grid**, `grid-template-columns:1fr 1fr`, `gap:32px`, `align-items:start`, `margin-top:56px`.
- **Left column** — flex column, `gap:32px`, **two** paragraphs.
- **Right column** — flex column, `gap:32px`, **three** paragraphs.
- Each paragraph: `--fw-regular`, `--text-md` (16px), `line-height:--leading-relaxed`, color
  `--text-body`, `text-wrap:pretty`, left-aligned.

### Responsive
- At **≤1279px** the band collapses to a single column (`grid-template-columns:1fr`). Because the left
  column wrapper precedes the right in the DOM and the grid gap equals the in-column gap (`32px`), all
  five paragraphs read as one continuous, evenly-spaced column in original order (left's 2 first, then
  right's 3). Keep the column gap and grid gap equal so the merged rhythm stays uniform.
- Full reading order on narrow viewports: heading → supporting paragraph → hero image →
  left paragraph 1 → left paragraph 2 → right paragraph 1 → right paragraph 2 → right paragraph 3.

---

## Content (copy)
All copy is in Joushen's executive voice (English, sentence case, no emoji). It's editorial placeholder —
**confirm/replace with the real article** before publishing. References to NCA / SAMA CSF / PDPL are
intentional brand signals; keep them accurate to the published piece. Full text is in the prototype file.

## Interactions & Behavior
- Static content section — no JS behavior required.
- **Reveal-on-scroll (optional):** if the Joushen site animates sections in on scroll, apply the same
  pattern (short fade + small `translateY` rise, 120–360ms, ease `cubic-bezier(0.16,1,0.3,1)`), respecting
  `prefers-reduced-motion`. Don't add a bespoke animation if the site doesn't already do this.
- **Selection:** lime background, navy text (per Joushen states).

## Design Tokens used (all from the Joushen Design System)
**Color:** `--surface-page`, `--text-strong`, `--text-body`, `--text-muted`, `--brand-accent`,
`--text-on-accent`.
**Type:** `--font-sans`, `--font-display`, `--font-mono`, `--fw-bold`, `--fw-regular`, `--text-xs`,
`--text-md`, `--text-lg`, `--leading-tight`, `--leading-relaxed`, `--tracking-tighter`, `--tracking-wider`.
**Spacing/layout:** `--container-xl` (1320px); section paddings `96/72px` vertical, `52/24px` horizontal;
gaps `32px`; band `margin-top:56px`; header `margin-bottom:48px`.
**Radius/elevation:** hero `border-radius:16px`, `--shadow-md`.

## Files
- **`Joushen Article.dc.html`** — the section prototype (the design to recreate). Loads the Joushen
  token stylesheets + `_ds_bundle.js` from `_ds/joushen-design-system-0e80c5c9-.../`.
- **`reference/image-slot.js`** — prototype-only hero placeholder helper. **Do not ship**; replace the
  `<image-slot>` with a real `<img>` in production.
