'use client';

/**
 * CookieConsentBanner
 * --------------------------------------------------------------------------
 * Two presentations from one component:
 *   - mode="banner"      → bottom-docked first-visit notice with 3 actions
 *   - mode="preferences" → accessible modal dialog (necessary always on,
 *                          analytics toggle, save, privacy policy link)
 *
 * Arabic / RTL. Visual identity matches the Miras site:
 *   bg #050505 / surface #0a0a0f, accent #5578FF (hover #6B8FFF),
 *   hairline rgba(255,255,255,.1), text #F7F7F5.
 *
 * Accessibility:
 *   - role="dialog" aria-modal, labelled + described
 *   - Escape closes, Tab is focus-trapped, focus moves into the dialog
 *   - role="switch" with aria-checked for the analytics toggle
 *   - visible focus states (see :focus-visible rule)
 *
 * NOTE: styling here is inline + a tiny scoped <style> for brevity so the
 * file is self-contained. In your codebase, move these into your styling
 * system (CSS Modules / Tailwind / styled) and reuse existing button + dialog
 * primitives where you have them.
 */

import { useEffect, useRef, useState } from 'react';

const ACCENT = '#5578FF';
const ACCENT_HOVER = '#6B8FFF';
const PRIVACY_POLICY_HREF = '/privacy-policy'; // adjust to your route

type Props = {
  mode: 'banner' | 'preferences';
  initialAnalytics: boolean;
  onAcceptAll: () => void;
  onRejectAll: () => void;
  onSave: (analytics: boolean) => void;
  onOpenPreferences: () => void;
  onClose: () => void;
};

export default function CookieConsentBanner({
  mode,
  initialAnalytics,
  onAcceptAll,
  onRejectAll,
  onSave,
  onOpenPreferences,
  onClose,
}: Props) {
  const [analytics, setAnalytics] = useState(initialAnalytics);
  const dialogRef = useRef<HTMLDivElement>(null);
  const previouslyFocused = useRef<HTMLElement | null>(null);

  useEffect(() => setAnalytics(initialAnalytics), [initialAnalytics]);

  // Dialog focus handling + keyboard support (preferences mode only).
  useEffect(() => {
    if (mode !== 'preferences') return;
    previouslyFocused.current = document.activeElement as HTMLElement;
    const dlg = dialogRef.current;
    const first = dlg?.querySelector<HTMLElement>('button, a[href], input, [tabindex]:not([tabindex="-1"])');
    first?.focus();

    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose();
      } else if (e.key === 'Tab' && dlg) {
        const f = dlg.querySelectorAll<HTMLElement>(
          'button, a[href], input, [tabindex]:not([tabindex="-1"])',
        );
        if (!f.length) return;
        const firstEl = f[0];
        const lastEl = f[f.length - 1];
        if (e.shiftKey && document.activeElement === firstEl) {
          e.preventDefault();
          lastEl.focus();
        } else if (!e.shiftKey && document.activeElement === lastEl) {
          e.preventDefault();
          firstEl.focus();
        }
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      previouslyFocused.current?.focus?.();
    };
  }, [mode, onClose]);

  // ---- BANNER ----------------------------------------------------------
  if (mode === 'banner') {
    return (
      <div dir="rtl" role="region" aria-label="إشعار الخصوصية" className="miras-consent-banner-wrap">
        <Scoped />
        <div className="miras-consent-banner">
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 11, marginBottom: 10 }}>
              <span className="miras-consent-icon" aria-hidden>
                <ShieldIcon />
              </span>
              <h2 style={{ fontFamily: 'var(--font-serif, ThmanyahSerifDisplay), serif', fontWeight: 700, fontSize: 19 }}>
                خصوصيتك تهمّنا
              </h2>
            </div>
            <p style={{ fontWeight: 300, fontSize: 13.5, lineHeight: 1.95, color: 'rgba(247,247,245,.55)', maxWidth: 760 }}>
              نستخدم وسائل تخزين ضرورية لتشغيل الموقع وتذكّر تفضيلاتك. ويمكنك اختيار السماح بتحليلات الاستخدام
              المجهولة لتحسين محتوى وتجربة مِراس. لن يتم تشغيل التحليلات الاختيارية قبل موافقتك.
            </p>
          </div>
          <div className="miras-consent-actions">
            <button type="button" className="mc-btn-ghost" onClick={onOpenPreferences}>
              إدارة التفضيلات
            </button>
            <button type="button" className="mc-btn-secondary" onClick={onRejectAll}>
              رفض التحليلات غير الضرورية
            </button>
            <button type="button" className="mc-btn-primary" onClick={onAcceptAll}>
              قبول التحليلات
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ---- PREFERENCES DIALOG ---------------------------------------------
  return (
    <div dir="rtl" className="miras-consent-overlay" onClick={onClose}>
      <Scoped />
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="mc-title"
        aria-describedby="mc-desc"
        className="miras-consent-dialog"
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', gap: 16, marginBottom: 8 }}>
          <h2 id="mc-title" style={{ fontFamily: 'var(--font-serif, ThmanyahSerifDisplay), serif', fontWeight: 700, fontSize: 24 }}>
            إدارة تفضيلات الخصوصية
          </h2>
          <button type="button" aria-label="إغلاق" className="mc-close" onClick={onClose}>
            <CloseIcon />
          </button>
        </div>
        <p id="mc-desc" style={{ fontWeight: 300, fontSize: 13.5, lineHeight: 1.9, color: 'rgba(247,247,245,.5)', marginBottom: 28 }}>
          تحكّم في طريقة استخدام مِراس لوسائل التخزين. تبقى الفئات الضرورية مفعّلة دائماً لضمان عمل الموقع.
        </p>

        {/* Necessary — always on, disabled */}
        <div className="mc-row">
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="mc-row-title">ضرورية</div>
            <div className="mc-row-desc">لازمة لتشغيل الموقع وتذكّر تفضيلاتك. لا يمكن إيقافها.</div>
          </div>
          <span aria-hidden className="mc-switch mc-switch--on mc-switch--locked">
            <span className="mc-knob" style={{ left: 2 }} />
          </span>
        </div>

        {/* Analytics — toggle, off by default */}
        <div className="mc-row" style={{ marginBottom: 28 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div className="mc-row-title">تحليلات الاستخدام</div>
            <div className="mc-row-desc">
              قياسات مجهولة لتحسين المحتوى والتجربة عبر Vercel Analytics. تُشغّل فقط بعد موافقتك.
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={analytics}
            aria-label="تحليلات الاستخدام"
            className={`mc-switch ${analytics ? 'mc-switch--on' : ''}`}
            onClick={() => setAnalytics((v) => !v)}
          >
            <span className="mc-knob" style={analytics ? { left: 2 } : { right: 2 }} />
          </button>
        </div>

        <button type="button" className="mc-btn-primary mc-btn-block" onClick={() => onSave(analytics)}>
          حفظ التفضيلات
        </button>

        <div style={{ textAlign: 'center', marginTop: 18 }}>
          <a className="mc-link" href={PRIVACY_POLICY_HREF}>
            سياسة الخصوصية
          </a>
        </div>
      </div>
    </div>
  );
}

/* ---- icons ---- */
function ShieldIcon() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke={ACCENT} strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
    </svg>
  );
}
function CloseIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 6L6 18" />
      <path d="M6 6l12 12" />
    </svg>
  );
}

/* ---- scoped styles (move to your styling system) ---- */
function Scoped() {
  return (
    <style>{`
      .miras-consent-banner-wrap{position:fixed;right:0;left:0;bottom:0;z-index:200;padding:20px;display:flex;justify-content:center;pointer-events:none}
      .miras-consent-banner{pointer-events:auto;width:100%;max-width:1180px;background:rgba(10,10,15,.96);backdrop-filter:blur(20px);border:1px solid rgba(255,255,255,.1);border-radius:16px;box-shadow:0 24px 80px rgba(0,0,0,.6);padding:26px 30px;display:flex;align-items:center;gap:34px;color:#F7F7F5;font-family:var(--font-sans, ThmanyahSans),sans-serif}
      .miras-consent-icon{display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:9px;background:rgba(85,120,255,.12);border:1px solid rgba(85,120,255,.25);flex-shrink:0}
      .miras-consent-actions{display:flex;align-items:center;gap:12px;flex-shrink:0}
      .mc-btn-ghost{padding:12px 20px;background:none;border:none;color:rgba(247,247,245,.6);font:inherit;font-size:13.5px;font-weight:500;cursor:pointer;transition:color .2s;white-space:nowrap}
      .mc-btn-ghost:hover{color:#F7F7F5}
      .mc-btn-secondary{padding:12px 22px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.14);border-radius:8px;color:#F7F7F5;font:inherit;font-size:13.5px;font-weight:500;cursor:pointer;transition:background .25s,border-color .25s;white-space:nowrap}
      .mc-btn-secondary:hover{background:rgba(255,255,255,.09);border-color:rgba(255,255,255,.24)}
      .mc-btn-primary{padding:12px 26px;background:${ACCENT};border:none;border-radius:8px;color:#F7F7F5;font:inherit;font-size:13.5px;font-weight:600;cursor:pointer;transition:background .25s,box-shadow .25s,transform .2s;white-space:nowrap}
      .mc-btn-primary:hover{background:${ACCENT_HOVER};box-shadow:0 8px 30px rgba(85,120,255,.4);transform:translateY(-2px)}
      .mc-btn-block{width:100%;display:inline-flex;align-items:center;justify-content:center;font-size:15px;padding:15px 28px}
      .miras-consent-overlay{position:fixed;inset:0;z-index:300;background:rgba(2,2,4,.72);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;padding:24px}
      .miras-consent-dialog{width:100%;max-width:520px;background:#0a0a0f;border:1px solid rgba(255,255,255,.1);border-radius:18px;box-shadow:0 32px 90px rgba(0,0,0,.7);padding:36px 34px;max-height:90vh;overflow-y:auto;color:#F7F7F5;font-family:var(--font-sans, ThmanyahSans),sans-serif}
      .mc-close{display:inline-flex;align-items:center;justify-content:center;width:34px;height:34px;border-radius:8px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.1);color:rgba(247,247,245,.6);cursor:pointer;transition:background .2s,color .2s;flex-shrink:0}
      .mc-close:hover{background:rgba(255,255,255,.09);color:#F7F7F5}
      .mc-row{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;padding:20px;background:rgba(255,255,255,.02);border:1px solid rgba(255,255,255,.07);border-radius:12px;margin-bottom:14px}
      .mc-row-title{font-size:14.5px;font-weight:600;color:#F7F7F5;margin-bottom:6px}
      .mc-row-desc{font-size:12.5px;line-height:1.8;color:rgba(247,247,245,.45)}
      .mc-switch{position:relative;flex-shrink:0;width:46px;height:26px;border-radius:100px;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.18);cursor:pointer;padding:0;transition:background .25s,border-color .25s}
      .mc-switch--on{background:rgba(85,120,255,.9);border-color:${ACCENT}}
      .mc-switch--locked{opacity:.7;cursor:not-allowed}
      .mc-knob{position:absolute;top:2px;width:20px;height:20px;border-radius:50%;background:#F7F7F5;transition:left .25s,right .25s}
      .mc-link{font-size:12.5px;color:${ACCENT};border-bottom:1px solid rgba(85,120,255,.4);transition:color .2s}
      .mc-link:hover{color:${ACCENT_HOVER}}
      .miras-consent-dialog :focus-visible,.miras-consent-banner :focus-visible{outline:2px solid ${ACCENT};outline-offset:2px;border-radius:6px}
      @media(max-width:680px){
        .miras-consent-banner{flex-direction:column;align-items:stretch;gap:20px}
        .miras-consent-actions{flex-wrap:wrap}
        .miras-consent-actions button{flex:1 1 auto}
      }
    `}</style>
  );
}
