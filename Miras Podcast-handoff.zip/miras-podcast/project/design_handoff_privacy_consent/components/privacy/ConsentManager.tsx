'use client';

/**
 * ConsentManager
 * --------------------------------------------------------------------------
 * Single source of truth for the visitor's privacy/analytics consent.
 *
 * Responsibilities:
 *  - SSR/hydration-safe: only touches localStorage AFTER mount.
 *  - Reads/writes the consent record under `miras_cookie_consent_v1`.
 *  - Re-prompts when the stored `version` differs from CONSENT_VERSION.
 *  - Renders <CookieConsentBanner /> on first visit (no valid record).
 *  - Renders Vercel <Analytics /> ONLY when analytics consent === true.
 *  - Exposes a context so any component (e.g. PrivacyPreferencesButton,
 *    the footer, the Privacy Policy page) can open the preferences dialog
 *    or read/update consent at any time.
 *
 * Drop <ConsentManager /> in once at the app root (see README).
 * Keep it dependency-free except for @vercel/analytics, which is already
 * installed in this project.
 */

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { Analytics } from '@vercel/analytics/react';
import CookieConsentBanner from './CookieConsentBanner';

export const CONSENT_KEY = 'miras_cookie_consent_v1';
export const CONSENT_VERSION = '1';

export type ConsentRecord = {
  necessary: true;
  analytics: boolean;
  updatedAt: string; // ISO timestamp
  version: string;
};

type ConsentContextValue = {
  /** null until mounted/read; then the saved record or null if none/invalid */
  consent: ConsentRecord | null;
  /** true once we've read localStorage on the client */
  hydrated: boolean;
  analyticsEnabled: boolean;
  acceptAll: () => void;
  rejectAll: () => void;
  /** persist an explicit analytics choice */
  setAnalytics: (value: boolean) => void;
  openPreferences: () => void;
  closePreferences: () => void;
  preferencesOpen: boolean;
};

const ConsentContext = createContext<ConsentContextValue | null>(null);

export function useConsent(): ConsentContextValue {
  const ctx = useContext(ConsentContext);
  if (!ctx) throw new Error('useConsent must be used within <ConsentManager>');
  return ctx;
}

function readConsent(): ConsentRecord | null {
  try {
    const raw = window.localStorage.getItem(CONSENT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as ConsentRecord;
    if (!parsed || parsed.version !== CONSENT_VERSION) return null; // version bump → re-prompt
    return parsed;
  } catch {
    return null;
  }
}

function writeConsent(analytics: boolean): ConsentRecord {
  const record: ConsentRecord = {
    necessary: true,
    analytics,
    updatedAt: new Date().toISOString(),
    version: CONSENT_VERSION,
  };
  try {
    window.localStorage.setItem(CONSENT_KEY, JSON.stringify(record));
  } catch {
    /* storage may be unavailable; fail silently */
  }
  return record;
}

export default function ConsentManager({ children }: { children?: React.ReactNode }) {
  const [hydrated, setHydrated] = useState(false);
  const [consent, setConsent] = useState<ConsentRecord | null>(null);
  const [bannerOpen, setBannerOpen] = useState(false);
  const [preferencesOpen, setPreferencesOpen] = useState(false);

  // Read stored consent only on the client, after mount (hydration-safe).
  useEffect(() => {
    const existing = readConsent();
    setConsent(existing);
    setBannerOpen(!existing); // show banner only when there's no valid record
    setHydrated(true);
  }, []);

  const persist = useCallback((analytics: boolean) => {
    const record = writeConsent(analytics);
    setConsent(record);
    setBannerOpen(false);
    setPreferencesOpen(false);
  }, []);

  const value = useMemo<ConsentContextValue>(
    () => ({
      consent,
      hydrated,
      analyticsEnabled: !!consent?.analytics,
      acceptAll: () => persist(true),
      rejectAll: () => persist(false),
      setAnalytics: (v: boolean) => persist(v),
      openPreferences: () => setPreferencesOpen(true),
      closePreferences: () => setPreferencesOpen(false),
      preferencesOpen,
    }),
    [consent, hydrated, persist, preferencesOpen],
  );

  return (
    <ConsentContext.Provider value={value}>
      {children}

      {/* Analytics is mounted ONLY after explicit consent. Never on first load. */}
      {hydrated && consent?.analytics ? <Analytics /> : null}

      {/* First-visit banner (also re-openable as the preferences dialog). */}
      {hydrated && (bannerOpen || preferencesOpen) ? (
        <CookieConsentBanner
          mode={preferencesOpen ? 'preferences' : 'banner'}
          initialAnalytics={!!consent?.analytics}
          onAcceptAll={() => persist(true)}
          onRejectAll={() => persist(false)}
          onSave={(analytics) => persist(analytics)}
          onOpenPreferences={() => setPreferencesOpen(true)}
          onClose={() => {
            setPreferencesOpen(false);
            // Closing the preferences dialog should NOT dismiss a first-visit banner.
            if (!consent) setBannerOpen(true);
          }}
        />
      ) : null}
    </ConsentContext.Provider>
  );
}
