'use client';

/**
 * PrivacyPreferencesButton
 * --------------------------------------------------------------------------
 * A plain text/link button that reopens the preferences dialog at any time.
 * Place it in the site footer (and anywhere else you want a "manage privacy"
 * affordance). Must be a descendant of <ConsentManager />.
 *
 * Renders nothing visual of its own beyond a button; styling matches the
 * footer link style of the Miras site by default but accepts className.
 */

import { useConsent } from './ConsentManager';

export default function PrivacyPreferencesButton({
  className,
  children = 'إدارة إعدادات الخصوصية',
}: {
  className?: string;
  children?: React.ReactNode;
}) {
  const { openPreferences } = useConsent();
  return (
    <button
      type="button"
      onClick={openPreferences}
      className={className}
      style={
        className
          ? undefined
          : {
              fontSize: 12,
              color: 'rgba(247,247,245,.3)',
              background: 'none',
              border: 'none',
              cursor: 'pointer',
              fontFamily: 'inherit',
              transition: 'color .2s',
            }
      }
    >
      {children}
    </button>
  );
}
