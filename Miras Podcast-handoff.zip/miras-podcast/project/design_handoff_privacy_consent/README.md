# Handoff: Privacy & Consent System + New Pages (Miras Podcast)

## Overview
This package updates the **Miras Podcast | مُرونة الأعمال** website (`miras.resiliences.business`)
with a privacy-first consent system and several new pages. The work is **additive** — it must
preserve all current functionality, routes, content, integrations, and responsiveness. Only add the
items described here and the small, additive styles/links they require.

It bundles two related deliverables:

1. **Privacy & Consent system** (functional, code provided): a cookie/analytics consent banner +
   accessible preferences dialog, gated Vercel Analytics, a footer "manage privacy" link, and a full
   **Privacy Policy** page (Arabic, 19 sections).
2. **New content pages** (design references to recreate): a **Blog** page, a **Guest Application**
   page, and the **Privacy Policy** page — all linked from the main site nav/footer.

The site is **Arabic, RTL**, dark theme. Every addition follows the existing Miras visual identity.

---

## About the Design Files
The `.dc.html` files in this bundle are **design references** — HTML prototypes showing the intended
look and behavior. They are **not** to be shipped as-is. Recreate them inside the existing
**Next.js** codebase using its established conventions (App Router/Pages Router, your component and
styling systems, your fonts).

The **exception** is the `components/privacy/*.tsx` folder: those are **production-ready React/Next.js
components** written to the spec — review, wire them in, and adapt styling to your system. They are
dependency-free apart from `@vercel/analytics`, which is already installed.

## Fidelity
**High-fidelity (hifi).** Colors, typography, spacing, and interactions are final and specified below.
Match them precisely using the site's existing tokens, fonts, and components.

---

## Scope — what must change

### Pages
- **Home** (`MIRAS Podcast.dc.html` → your home route): only nav + footer links change (additive).
- **ADD: Blog page** — new route (e.g. `/blog`).
- **ADD: Guest Application page** — new route (e.g. `/guest` or `/apply`).
- **ADD: Privacy Policy page** — new route `/privacy-policy`.
- **Consent UI** is global (mounted at the app root), not a page.

### Sections / Components
- **ADD (code provided): `components/privacy/ConsentManager.tsx`** — context + banner host + gated
  `<Analytics />`. Mount once at the app root.
- **ADD (code provided): `components/privacy/CookieConsentBanner.tsx`** — banner + accessible
  preferences dialog (one component, two modes).
- **ADD (code provided): `components/privacy/PrivacyPreferencesButton.tsx`** — footer "manage
  privacy" trigger; reopens the dialog anytime.
- **ADD: Privacy Policy page content** (19 sections — see `MIRAS Privacy.dc.html`).
- **ADD: Blog page** — header row + responsive card grid + newsletter block (see `MIRAS Blog.dc.html`).
- **ADD: Guest Application page** — editorial header, 3 benefit cards, two-column form, consent
  checkbox, submit + success state (see `MIRAS Guest.dc.html`).
- **REUSE (do not restyle):** existing nav bar, footer, pill/eyebrow badge, primary button
  (`#5578FF`), section container (`max-width` + side padding), card surface (`#0a0a0f` + hairline
  border), and the existing `data-reveal` scroll-reveal animation.

### Existing analytics — REQUIRED change
- **Remove any unconditional `<Analytics />`** from `app/layout.tsx`, `pages/_app.tsx`, or any global
  layout. Analytics must render **only** through `ConsentManager`, and **only** after analytics
  consent is `true`. Do not load `@vercel/analytics` on first page load before consent.

### Images / Assets
- No new image assets required for the consent system or Privacy Policy.
- Blog/Guest pages reuse existing project imagery and the blue dotted-grid motif already on the site.
- Icons are inline Lucide-style SVGs (thin line, rounded caps, ~1.8–2px stroke) — use your existing
  icon approach.

### Styles
- Additive only. New CSS: the scoped rules inside `CookieConsentBanner.tsx` (move into your styling
  system), input `::placeholder` color, `:focus`/`:focus-visible` states, and the responsive
  stacking media queries noted per page. All colors/fonts/radii come from existing site values
  (see Design Tokens). No new color or font is introduced.

---

## The consent record (localStorage)
- **Key:** `miras_cookie_consent_v1`
- **Value:**
  ```json
  { "necessary": true, "analytics": true, "updatedAt": "2026-06-19T12:00:00.000Z", "version": "1" }
  ```
- **Version gate:** `version` is `"1"` (`CONSENT_VERSION`). If you bump it later, every visitor is
  re-prompted automatically (a stored record whose `version` differs is treated as absent).
- **SSR/hydration safety:** localStorage is read only inside `useEffect` after mount. Server render
  and first client render show no banner and no `<Analytics />`; the banner appears post-hydration
  only when there's no valid record.

## Functional requirements (verify against these)
1. **First visit:** banner shows; `<Analytics />` is NOT rendered/loaded.
2. **"قبول التحليلات" (Accept):** save `analytics: true`, close banner, render `<Analytics />`
   immediately.
3. **"رفض التحليلات غير الضرورية" (Reject):** save `analytics: false`, close banner, never render
   `<Analytics />`.
4. **"إدارة التفضيلات" (Manage):** open preferences dialog; saving applies the chosen analytics value.
5. **Footer link "إدارة إعدادات الخصوصية":** reopens the preferences dialog at any time
   (`PrivacyPreferencesButton`).
6. **Version bump:** changing `CONSENT_VERSION` re-shows the banner.
7. **No third-party trackers** beyond Vercel Web Analytics (no GA, Meta Pixel, Hotjar, etc.).
8. **Dependency-free** except already-installed `@vercel/analytics`.

## Wiring (root + footer)
```tsx
// app/layout.tsx (App Router) — remove any existing unconditional <Analytics/> here
import ConsentManager from '@/components/privacy/ConsentManager';

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body>
        <ConsentManager>{children}</ConsentManager>
      </body>
    </html>
  );
}
```
```tsx
// Footer.tsx
import PrivacyPreferencesButton from '@/components/privacy/PrivacyPreferencesButton';
// ...
<a href="/privacy-policy">سياسة الخصوصية</a>
<PrivacyPreferencesButton />   {/* إدارة إعدادات الخصوصية */}
```
> If you use the Pages Router, mount `<ConsentManager>` in `pages/_app.tsx` wrapping `<Component/>`,
> and ensure these components run client-side (`'use client'` is already declared).

---

## Screens / Views

### 1. Consent Banner (mode="banner")
- **Position:** `position:fixed; bottom:0; left:0; right:0; z-index:200;` centered, `padding:20px`,
  wrapper `pointer-events:none`, card `pointer-events:auto`.
- **Card:** `max-width:1180px`, `background:rgba(10,10,15,.96)`, `backdrop-filter:blur(20px)`,
  `border:1px solid rgba(255,255,255,.1)`, `border-radius:16px`,
  `box-shadow:0 24px 80px rgba(0,0,0,.6)`, `padding:26px 30px`, flex row, `gap:34px`.
- **Heading:** "خصوصيتك تهمّنا" — serif 700, 19px, preceded by a 34px rounded shield icon tile
  (`rgba(85,120,255,.12)` bg, `rgba(85,120,255,.25)` border).
- **Body:** 13.5px / line-height 1.95, `rgba(247,247,245,.55)`, max-width 760px — exact copy:
  "نستخدم وسائل تخزين ضرورية لتشغيل الموقع وتذكّر تفضيلاتك. ويمكنك اختيار السماح بتحليلات الاستخدام المجهولة لتحسين محتوى وتجربة مِراس. لن يتم تشغيل التحليلات الاختيارية قبل موافقتك."
- **Actions (right→left in RTL):**
  - Ghost text button: **"إدارة التفضيلات"** (opens dialog).
  - Secondary: **"رفض التحليلات غير الضرورية"** — `rgba(255,255,255,.05)` bg, hairline border, radius 8.
  - Primary: **"قبول التحليلات"** — `#5578FF`, radius 8, hover `#6B8FFF` + glow + `translateY(-2px)`.
- **Responsive (≤680px):** card stacks (`flex-direction:column`), actions wrap full-width.

### 2. Preferences Dialog (mode="preferences")
- **Overlay:** `position:fixed; inset:0; z-index:300; background:rgba(2,2,4,.72); backdrop-filter:blur(6px);`
  centered; click overlay = close.
- **Dialog:** `max-width:520px`, `background:#0a0a0f`, hairline border, `border-radius:18px`,
  `box-shadow:0 32px 90px rgba(0,0,0,.7)`, `padding:36px 34px`, `max-height:90vh; overflow-y:auto`.
  `role="dialog" aria-modal="true"` + `aria-labelledby`/`aria-describedby`.
- **Title:** "إدارة تفضيلات الخصوصية" (serif 700, 24px) with a 34px close (✕) button.
- **Description:** "تحكّم في طريقة استخدام مِراس لوسائل التخزين. تبقى الفئات الضرورية مفعّلة دائماً لضمان عمل الموقع."
- **Rows** (each: `padding:20px`, `rgba(255,255,255,.02)` bg, hairline border, radius 12):
  - **ضرورية** — description "لازمة لتشغيل الموقع وتذكّر تفضيلاتك. لا يمكن إيقافها." — switch **on + disabled**
    (`role` omitted / `aria-hidden`, `cursor:not-allowed`, opacity .7).
  - **تحليلات الاستخدام** — description references Vercel Analytics; `role="switch"` with
    `aria-checked`, **off by default**. Track on = `rgba(85,120,255,.9)`; knob 20px white.
- **Save:** full-width primary **"حفظ التفضيلات"**.
- **Link:** centered **"سياسة الخصوصية"** → `/privacy-policy`.
- **A11y:** focus moves into dialog on open; **Escape** closes; **Tab** is focus-trapped; focus
  returns to the previously focused element on close; visible `:focus-visible` outline (`2px #5578FF`).

### 3. Privacy Policy page (`/privacy-policy`)
- Centered article, `max-width:780px`, `padding:150px 52px 120px` (top clears the fixed nav).
- **Header:** eyebrow pill ("بودكاست مِراس · مُرونة الأعمال"), `<h1>` "سياسة الخصوصية" (serif 700,
  clamp(36px,5vw,56px)), mono "آخر تحديث: 19 يونيو 2026", two intro paragraphs.
- **19 numbered sections**, each: `border-top:1px solid rgba(255,255,255,.07)`, `padding:34px 0`,
  `<h2>` with a mono blue section number (`01`…`19`), body paragraphs (300, 15.5px, lh 2.05,
  `rgba(247,247,245,.62)`), and bulleted `<ul>` (custom blue dot markers). Full copy is in
  `MIRAS Privacy.dc.html` — reproduce verbatim.
- `<code>` style for domain/email: mono, `#8FA8FF`, `rgba(85,120,255,.1)` bg, `dir="ltr"`.
- **Close affordance:** a fixed top-left **"إغلاق" (✕)** pill → home, plus **Escape** key → home,
  plus the nav logo → home.
- **Section 08** links to the preferences dialog/manage page; **Section 19** has primary
  "إدارة إعدادات الخصوصية" + secondary "تواصل معنا" buttons.
- Footer links: **سياسة الخصوصية** (current), **إدارة إعدادات الخصوصية**, **المدوّنة**.

### 4. Blog page (`/blog`) — see `MIRAS Blog.dc.html`
- Centered container `max-width:1320px`, side padding `52px`.
- **Header block:** `<h1>` "من المدوّنة" + a "عرض المزيد" pill (trailing arrow) on the same baseline;
  supporting paragraph below.
- **Card grid:** 2 columns desktop → 1 column ≤880px, `gap:28px`. Each card (`#0a0a0f`, hairline
  border, radius 16, `padding:36px 34px`): category badge + time-ago (clock) row, multi-line serif
  headline link, excerpt, footer row (avatar + author + date·read-time + "اقرأ المزيد").
- **Newsletter block:** sub-heading, paragraph, inline email input (mail icon) + "اشترك" button,
  fine print with privacy link.

### 5. Guest Application page (`/guest`) — see `MIRAS Guest.dc.html`
- Centered container `max-width:1280px`, side padding `52px`.
- **Editorial header (centered):** eyebrow "بودكاست مِراس · التقديم كضيف", `<h1>`
  "شارك خبرتك. ووجِّه دفّة الحوار.", supporting paragraph, bold invitation line.
- **3 benefit cards** (icons mic / broadcast / lightbulb): 3 cols desktop → 1 col ≤880px.
- **Form** `max-width:720px`, two-column grid (`1fr 1fr`) collapsing to one column ≤880px:
  - Row 1: الاسم الكامل* / المسمى الوظيفي*
  - Row 2: المؤسسة / الشركة* / البريد المهني*
  - Row 3: ملف لينكدإن / رقم الهاتف (country-code `<select>` + tel input)
  - Row 4: الدولة / المنطقة (default المملكة العربية السعودية) / لغة الحلقة المفضلة (العربية / الإنجليزية / العربية والإنجليزية)
  - Full width: الموضوع المقترح للحلقة* (helper text), لماذا يهمّ هذا الموضوع جمهورنا؟* (label has a ؟ icon, resizable textarea), هل من شيء آخر تودّ إخبارنا به؟ (optional textarea)
  - **Consent checkbox** with links "شروط مشاركة الضيوف" + "سياسة الخصوصية"
  - Full-width primary submit **"قدّم طلبك للانضمام كضيف في مِراس"** (trailing arrow) + reassurance note
  - **Success state** after submit: confirmation card "تم استلام طلبك".
- Wire the form to the site's existing mailing/CRM integration; if none, POST to a backend endpoint
  with required-field + email validation, loading/success/error states (Arabic copy).

---

## Interactions & Behavior
- **Transitions:** 120–360ms, ease-out; primary button hover lifts `translateY(-2px)` + blue glow
  `0 8px 30–40px rgba(85,120,255,.38–.4)`.
- **Scroll reveal:** reuse the site's `[data-reveal]` IntersectionObserver pattern (opacity 0→1,
  `translateY(22px)→0`, `cubic-bezier(0.16,1,0.3,1)`, ~0.85s, optional `data-delay`). Respect
  `prefers-reduced-motion`. Reveal above-the-fold elements immediately to avoid blank first paint.
- **Nav:** blurs/darkens after 60px scroll (existing behavior) — reuse.
- **Responsive:** all multi-column layouts stack at ≤880px (consent banner at ≤680px) in original
  reading order; large tap targets retained.

## State Management
- **Consent (global, in `ConsentManager`):** `consent: ConsentRecord | null`, `hydrated: boolean`,
  `bannerOpen`, `preferencesOpen`. Exposed via `useConsent()`:
  `acceptAll`, `rejectAll`, `setAnalytics`, `openPreferences`, `closePreferences`, `analyticsEnabled`.
- **Dialog (local):** `analytics` draft toggle (seeded from saved value, applied on Save).
- **Guest form (local):** field values + `status: idle|submitting|success|error` + `errorMessage`.
- **Data:** consent → localStorage only. Guest form → one POST to your endpoint/integration. No other
  fetching introduced.

## Design Tokens (reused from the existing Miras site)
**Colors:** bg `#050505`; surface `#0a0a0f` / `#060810`; text `#F7F7F5`; muted `rgba(247,247,245,.5)`
/ `.45` / `.4`; placeholder `rgba(247,247,245,.3)`; accent `#5578FF`, hover `#6B8FFF`, light
`#8FA8FF`; accent tints `rgba(85,120,255,.06/.1/.12/.16/.25/.38)`; hairline `rgba(255,255,255,.06–.14)`.
**Typography:** display/headings **ThmanyahSerifDisplay** (700); body/UI **ThmanyahSans** (300 body,
500/600 UI); mono eyebrows/labels **IBM Plex Mono** (11px, uppercase, letter-spacing .14em). Fonts
already loaded on the site — reuse, don't add new ones.
**Radius:** controls 6–8px; cards 12–18px; pill/badge 100px. **Shadow:** button glow
`0 8px 30–40px rgba(85,120,255,.38–.4)`; dialog `0 32px 90px rgba(0,0,0,.7)`; banner
`0 24px 80px rgba(0,0,0,.6)`.

## Privacy Policy page — required statement
The Privacy Policy must state that **analytics are activated only after the user's explicit consent**
(see sections 6 & 8 in `MIRAS Privacy.dc.html`, which already say so). Keep that language when you
port it.

## Files
**Production code (use/adapt):**
- `components/privacy/ConsentManager.tsx`
- `components/privacy/CookieConsentBanner.tsx`
- `components/privacy/PrivacyPreferencesButton.tsx`

**Design references (recreate in Next.js):**
- `reference/MIRAS Privacy.dc.html` — full Privacy Policy page (19 sections, exact copy).
- `reference/MIRAS Consent.dc.html` — interactive banner + preferences dialog prototype.
- `reference/MIRAS Blog.dc.html` — Blog page.
- `reference/MIRAS Guest.dc.html` — Guest Application page.
- `reference/MIRAS Podcast.dc.html` — full existing site (tokens, fonts, nav/footer, `data-reveal`,
  button/badge styles, and where new nav/footer links go).
