/* @ds-bundle: {"format":3,"namespace":"JoushenDesignSystem_0e80c5","components":[{"name":"Button","sourcePath":"components/buttons/Button.jsx"},{"name":"IconButton","sourcePath":"components/buttons/IconButton.jsx"},{"name":"Avatar","sourcePath":"components/data-display/Avatar.jsx"},{"name":"Badge","sourcePath":"components/data-display/Badge.jsx"},{"name":"Card","sourcePath":"components/data-display/Card.jsx"},{"name":"Stat","sourcePath":"components/data-display/Stat.jsx"},{"name":"Alert","sourcePath":"components/feedback/Alert.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Switch","sourcePath":"components/forms/Switch.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/buttons/Button.jsx":"326176e5a6b4","components/buttons/IconButton.jsx":"78f4ce4959da","components/data-display/Avatar.jsx":"8cbaf3002395","components/data-display/Badge.jsx":"f1bc3bba0312","components/data-display/Card.jsx":"8619f25605ef","components/data-display/Stat.jsx":"a368dc26d867","components/feedback/Alert.jsx":"f0436a7afee4","components/forms/Checkbox.jsx":"f242770fc70b","components/forms/Input.jsx":"ae22c6261d82","components/forms/Select.jsx":"4f134793e916","components/forms/Switch.jsx":"b09ddb1240ef","components/navigation/Tabs.jsx":"61d8b92f472f","ui_kits/console/console.jsx":"55e3f6e25021","ui_kits/website/website.jsx":"52c38fadba53"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.JoushenDesignSystem_0e80c5 = window.JoushenDesignSystem_0e80c5 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/buttons/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.jsn-btn{
  --_bg: var(--navy-500); --_fg:#fff; --_bd:transparent; --_bgh: var(--navy-600);
  display:inline-flex; align-items:center; justify-content:center; gap:8px;
  font-family:var(--font-sans); font-weight:600; letter-spacing:-0.01em;
  border:1.5px solid var(--_bd); background:var(--_bg); color:var(--_fg);
  border-radius:var(--radius-md); cursor:pointer; white-space:nowrap;
  transition:background var(--dur-fast) var(--ease-standard),
             transform var(--dur-fast) var(--ease-standard),
             box-shadow var(--dur-fast) var(--ease-standard), border-color var(--dur-fast);
  text-decoration:none;
}
.jsn-btn:hover{ background:var(--_bgh); }
.jsn-btn:active{ transform:translateY(1px); }
.jsn-btn:focus-visible{ outline:var(--focus-width) solid var(--focus-ring); outline-offset:var(--focus-offset); }
.jsn-btn[disabled]{ opacity:.45; cursor:not-allowed; transform:none; }

.jsn-btn--sm{ height:34px; padding:0 14px; font-size:13px; }
.jsn-btn--md{ height:42px; padding:0 20px; font-size:14px; }
.jsn-btn--lg{ height:52px; padding:0 28px; font-size:16px; border-radius:var(--radius-lg); }

.jsn-btn--primary{ --_bg:var(--lime-400); --_fg:var(--ink-850); --_bgh:var(--lime-300); }
.jsn-btn--primary:hover{ box-shadow:var(--shadow-accent); }
.jsn-btn--secondary{ --_bg:var(--navy-500); --_fg:#fff; --_bgh:var(--navy-600); }
.jsn-btn--ghost{ --_bg:transparent; --_fg:var(--navy-500); --_bgh:var(--navy-50); }
.jsn-btn--outline{ --_bg:transparent; --_fg:var(--navy-700); --_bd:var(--border-default); --_bgh:var(--gray-50); }
.jsn-btn--danger{ --_bg:var(--danger-500); --_fg:#fff; --_bgh:var(--danger-600); }
.jsn-btn--block{ width:100%; }
.jsn-btn__icon{ display:inline-flex; width:1.1em; height:1.1em; }
`;
if (typeof document !== "undefined" && !document.getElementById("jsn-btn-css")) {
  const s = document.createElement("style");
  s.id = "jsn-btn-css";
  s.textContent = CSS;
  document.head.appendChild(s);
}
function Button({
  children,
  variant = "primary",
  size = "md",
  block = false,
  iconLeft = null,
  iconRight = null,
  as = "button",
  className = "",
  ...props
}) {
  const Tag = as;
  const cls = ["jsn-btn", `jsn-btn--${variant}`, `jsn-btn--${size}`, block ? "jsn-btn--block" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement(Tag, _extends({
    className: cls
  }, props), iconLeft ? /*#__PURE__*/React.createElement("span", {
    className: "jsn-btn__icon"
  }, iconLeft) : null, children, iconRight ? /*#__PURE__*/React.createElement("span", {
    className: "jsn-btn__icon"
  }, iconRight) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/Button.jsx", error: String((e && e.message) || e) }); }

// components/buttons/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.jsn-iconbtn{
  --_bg:transparent; --_fg:var(--navy-600); --_bgh:var(--gray-100); --_bd:transparent;
  display:inline-flex; align-items:center; justify-content:center;
  border:1.5px solid var(--_bd); background:var(--_bg); color:var(--_fg);
  border-radius:var(--radius-md); cursor:pointer; padding:0;
  transition:background var(--dur-fast) var(--ease-standard), color var(--dur-fast), transform var(--dur-fast);
}
.jsn-iconbtn:hover{ background:var(--_bgh); }
.jsn-iconbtn:active{ transform:translateY(1px); }
.jsn-iconbtn:focus-visible{ outline:var(--focus-width) solid var(--focus-ring); outline-offset:2px; }
.jsn-iconbtn[disabled]{ opacity:.4; cursor:not-allowed; }
.jsn-iconbtn--sm{ width:32px; height:32px; }
.jsn-iconbtn--md{ width:40px; height:40px; }
.jsn-iconbtn--lg{ width:48px; height:48px; }
.jsn-iconbtn--solid{ --_bg:var(--navy-500); --_fg:#fff; --_bgh:var(--navy-600); }
.jsn-iconbtn--accent{ --_bg:var(--lime-400); --_fg:var(--ink-850); --_bgh:var(--lime-300); }
.jsn-iconbtn--outline{ --_bd:var(--border-default); --_bgh:var(--gray-50); }
.jsn-iconbtn svg{ width:1.15em; height:1.15em; display:block; }
.jsn-iconbtn--sm{ font-size:16px; } .jsn-iconbtn--md{ font-size:18px; } .jsn-iconbtn--lg{ font-size:20px; }
`;
if (typeof document !== "undefined" && !document.getElementById("jsn-iconbtn-css")) {
  const s = document.createElement("style");
  s.id = "jsn-iconbtn-css";
  s.textContent = CSS;
  document.head.appendChild(s);
}
function IconButton({
  children,
  variant = "ghost",
  size = "md",
  label,
  className = "",
  ...props
}) {
  const cls = ["jsn-iconbtn", `jsn-iconbtn--${variant}`, `jsn-iconbtn--${size}`, className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("button", _extends({
    className: cls,
    "aria-label": label,
    title: label
  }, props), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/buttons/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.jsn-avatar{
  display:inline-flex; align-items:center; justify-content:center; flex:0 0 auto;
  border-radius:50%; overflow:hidden; font-family:var(--font-sans); font-weight:600;
  background:var(--navy-500); color:#fff; position:relative; user-select:none;
}
.jsn-avatar img{ width:100%; height:100%; object-fit:cover; }
.jsn-avatar--accent{ background:var(--lime-400); color:var(--ink-850); }
.jsn-avatar--sage{ background:var(--sage-500); }
.jsn-avatar--blue{ background:var(--blue-500); color:var(--ink-850); }
.jsn-avatar--xs{ width:24px; height:24px; font-size:10px; }
.jsn-avatar--sm{ width:32px; height:32px; font-size:12px; }
.jsn-avatar--md{ width:40px; height:40px; font-size:14px; }
.jsn-avatar--lg{ width:56px; height:56px; font-size:19px; }
.jsn-avatar__ring{ box-shadow:0 0 0 2px #fff, 0 0 0 3.5px var(--lime-400); }
`;
if (typeof document !== "undefined" && !document.getElementById("jsn-avatar-css")) {
  const s = document.createElement("style");
  s.id = "jsn-avatar-css";
  s.textContent = CSS;
  document.head.appendChild(s);
}
function initials(name = "") {
  return name.trim().split(/\s+/).slice(0, 2).map(p => p[0]).join("").toUpperCase();
}
function Avatar({
  name,
  src,
  size = "md",
  color = "navy",
  ring = false,
  className = "",
  ...props
}) {
  const cls = ["jsn-avatar", `jsn-avatar--${size}`, color !== "navy" ? `jsn-avatar--${color}` : "", ring ? "jsn-avatar__ring" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls,
    title: name
  }, props), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name || ""
  }) : initials(name));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.jsn-badge{
  display:inline-flex; align-items:center; gap:6px; font-family:var(--font-sans); font-weight:600;
  font-size:12px; line-height:1; letter-spacing:0.01em; padding:5px 10px; border-radius:var(--radius-pill);
  white-space:nowrap;
}
.jsn-badge--neutral{ background:var(--gray-100); color:var(--gray-700); }
.jsn-badge--accent{ background:var(--lime-400); color:var(--ink-850); }
.jsn-badge--navy{ background:var(--navy-500); color:#fff; }
.jsn-badge--success{ background:#E3F1E7; color:var(--success-600); }
.jsn-badge--warning{ background:#FBF0D5; color:var(--warning-600); }
.jsn-badge--danger{ background:#F7DEDD; color:var(--danger-600); }
.jsn-badge--info{ background:var(--blue-100); color:var(--blue-700); }
.jsn-badge--outline{ background:transparent; color:var(--text-body); box-shadow:inset 0 0 0 1.5px var(--border-default); }
.jsn-badge__dot{ width:6px; height:6px; border-radius:50%; background:currentColor; }
.jsn-badge--square{ border-radius:var(--radius-sm); font-family:var(--font-mono); font-weight:500; letter-spacing:0.03em; }
`;
if (typeof document !== "undefined" && !document.getElementById("jsn-badge-css")) {
  const s = document.createElement("style");
  s.id = "jsn-badge-css";
  s.textContent = CSS;
  document.head.appendChild(s);
}
function Badge({
  children,
  variant = "neutral",
  dot = false,
  square = false,
  className = "",
  ...props
}) {
  const cls = ["jsn-badge", `jsn-badge--${variant}`, square ? "jsn-badge--square" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("span", _extends({
    className: cls
  }, props), dot ? /*#__PURE__*/React.createElement("span", {
    className: "jsn-badge__dot"
  }) : null, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.jsn-card{
  background:var(--surface-card); border:1px solid var(--border-subtle); border-radius:var(--radius-lg);
  box-shadow:var(--shadow-sm); padding:var(--space-6); position:relative;
  transition:box-shadow var(--dur-base) var(--ease-standard), transform var(--dur-base) var(--ease-standard), border-color var(--dur-base);
}
.jsn-card--interactive{ cursor:pointer; }
.jsn-card--interactive:hover{ box-shadow:var(--shadow-lg); transform:translateY(-2px); border-color:var(--border-default); }
.jsn-card--accent{ border-top:var(--border-accent-w) solid var(--lime-400); }
.jsn-card--dark{ background:var(--ink-850); border-color:var(--border-dark); color:var(--text-on-dark-body); box-shadow:none; }
.jsn-card--dark .jsn-card__title{ color:#fff; }
.jsn-card--flat{ box-shadow:none; }
.jsn-card__eyebrow{ font-family:var(--font-mono); font-size:11px; letter-spacing:0.14em; text-transform:uppercase; color:var(--text-muted); margin-bottom:10px; }
.jsn-card--dark .jsn-card__eyebrow{ color:var(--lime-400); }
.jsn-card__title{ font-family:var(--font-sans); font-weight:600; font-size:18px; letter-spacing:-0.015em; color:var(--text-strong); margin:0 0 6px; }
.jsn-card__body{ font-size:14px; line-height:1.6; color:inherit; }
`;
if (typeof document !== "undefined" && !document.getElementById("jsn-card-css")) {
  const s = document.createElement("style");
  s.id = "jsn-card-css";
  s.textContent = CSS;
  document.head.appendChild(s);
}
function Card({
  children,
  eyebrow,
  title,
  variant = "default",
  interactive = false,
  className = "",
  ...props
}) {
  const cls = ["jsn-card", variant !== "default" ? `jsn-card--${variant}` : "", interactive ? "jsn-card--interactive" : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, props), eyebrow ? /*#__PURE__*/React.createElement("div", {
    className: "jsn-card__eyebrow"
  }, eyebrow) : null, title ? /*#__PURE__*/React.createElement("h3", {
    className: "jsn-card__title"
  }, title) : null, children ? /*#__PURE__*/React.createElement("div", {
    className: "jsn-card__body"
  }, children) : null);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Card.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Stat.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.jsn-stat{ font-family:var(--font-sans); display:flex; flex-direction:column; gap:6px; }
.jsn-stat__label{ font-family:var(--font-mono); font-size:11px; letter-spacing:0.12em; text-transform:uppercase; color:var(--text-muted); }
.jsn-stat__value{ font-family:var(--font-sans); font-weight:700; font-size:44px; line-height:1; letter-spacing:-0.03em; color:var(--text-strong); }
.jsn-stat__value .jsn-stat__unit{ font-size:0.55em; font-weight:600; color:var(--lime-500); margin-left:2px; letter-spacing:0; }
.jsn-stat__delta{ display:inline-flex; align-items:center; gap:4px; font-size:13px; font-weight:600; }
.jsn-stat__delta--up{ color:var(--success-600); }
.jsn-stat__delta--down{ color:var(--danger-600); }
.jsn-stat--dark .jsn-stat__value{ color:#fff; }
.jsn-stat--dark .jsn-stat__label{ color:var(--navy-300); }
.jsn-stat--accent .jsn-stat__value{ color:var(--lime-400); }
`;
if (typeof document !== "undefined" && !document.getElementById("jsn-stat-css")) {
  const s = document.createElement("style");
  s.id = "jsn-stat-css";
  s.textContent = CSS;
  document.head.appendChild(s);
}
function Stat({
  label,
  value,
  unit,
  delta,
  trend,
  tone = "default",
  className = "",
  ...props
}) {
  const cls = ["jsn-stat", tone !== "default" ? `jsn-stat--${tone}` : "", className].filter(Boolean).join(" ");
  return /*#__PURE__*/React.createElement("div", _extends({
    className: cls
  }, props), label ? /*#__PURE__*/React.createElement("div", {
    className: "jsn-stat__label"
  }, label) : null, /*#__PURE__*/React.createElement("div", {
    className: "jsn-stat__value"
  }, value, unit ? /*#__PURE__*/React.createElement("span", {
    className: "jsn-stat__unit"
  }, unit) : null), delta ? /*#__PURE__*/React.createElement("span", {
    className: `jsn-stat__delta jsn-stat__delta--${trend === "down" ? "down" : "up"}`
  }, /*#__PURE__*/React.createElement("span", null, trend === "down" ? "▾" : "▴"), delta) : null);
}
Object.assign(__ds_scope, { Stat });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Stat.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Alert.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.jsn-alert{
  display:flex; gap:12px; align-items:flex-start; font-family:var(--font-sans);
  padding:14px 16px; border-radius:var(--radius-md); border:1px solid var(--border-subtle);
  background:var(--surface-card); border-left:var(--border-accent-w) solid var(--navy-500);
}
.jsn-alert__icon{ flex:0 0 auto; width:20px; height:20px; display:inline-flex; margin-top:1px; }
.jsn-alert__body{ font-size:14px; line-height:1.5; color:var(--text-body); }
.jsn-alert__title{ font-weight:600; color:var(--text-strong); margin-bottom:2px; }
.jsn-alert--info{ border-left-color:var(--blue-500); } .jsn-alert--info .jsn-alert__icon{ color:var(--blue-700); }
.jsn-alert--success{ border-left-color:var(--success-500); } .jsn-alert--success .jsn-alert__icon{ color:var(--success-600); }
.jsn-alert--warning{ border-left-color:var(--warning-500); } .jsn-alert--warning .jsn-alert__icon{ color:var(--warning-600); }
.jsn-alert--danger{ border-left-color:var(--danger-500); } .jsn-alert--danger .jsn-alert__icon{ color:var(--danger-600); }
`;
if (typeof document !== "undefined" && !document.getElementById("jsn-alert-css")) {
  const s = document.createElement("style");
  s.id = "jsn-alert-css";
  s.textContent = CSS;
  document.head.appendChild(s);
}
const ICONS = {
  info: "M12 16v-4 M12 8h.01",
  success: "M20 6 9 17l-5-5",
  warning: "M12 9v4 M12 17h.01 M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z",
  danger: "M12 8v4 M12 16h.01"
};
function Alert({
  children,
  title,
  variant = "info",
  icon = true,
  className = "",
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    className: ["jsn-alert", `jsn-alert--${variant}`, className].filter(Boolean).join(" "),
    role: "status"
  }, props), icon ? /*#__PURE__*/React.createElement("span", {
    className: "jsn-alert__icon"
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, variant === "info" || variant === "danger" ? /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "10"
  }) : null, /*#__PURE__*/React.createElement("path", {
    d: ICONS[variant]
  }))) : null, /*#__PURE__*/React.createElement("div", {
    className: "jsn-alert__body"
  }, title ? /*#__PURE__*/React.createElement("div", {
    className: "jsn-alert__title"
  }, title) : null, children));
}
Object.assign(__ds_scope, { Alert });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Alert.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.jsn-check{ display:inline-flex; align-items:flex-start; gap:10px; font-family:var(--font-sans); cursor:pointer; user-select:none; }
.jsn-check input{ position:absolute; opacity:0; width:0; height:0; }
.jsn-check__box{
  flex:0 0 auto; width:20px; height:20px; border:1.5px solid var(--border-strong); border-radius:var(--radius-sm);
  background:#fff; display:inline-flex; align-items:center; justify-content:center; margin-top:1px;
  transition:background var(--dur-fast), border-color var(--dur-fast);
}
.jsn-check__box svg{ width:14px; height:14px; color:var(--ink-850); opacity:0; transform:scale(.6); transition:opacity var(--dur-fast), transform var(--dur-fast); }
.jsn-check input:checked + .jsn-check__box{ background:var(--lime-400); border-color:var(--lime-500); }
.jsn-check input:checked + .jsn-check__box svg{ opacity:1; transform:scale(1); }
.jsn-check input:focus-visible + .jsn-check__box{ outline:3px solid var(--focus-ring); outline-offset:2px; }
.jsn-check input:disabled + .jsn-check__box{ background:var(--gray-100); border-color:var(--border-default); }
.jsn-check__text{ font-size:14px; color:var(--text-body); line-height:1.4; }
.jsn-check__text b{ display:block; color:var(--text-strong); font-weight:600; }
`;
if (typeof document !== "undefined" && !document.getElementById("jsn-check-css")) {
  const s = document.createElement("style");
  s.id = "jsn-check-css";
  s.textContent = CSS;
  document.head.appendChild(s);
}
function Checkbox({
  label,
  description,
  className = "",
  ...props
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: ["jsn-check", className].filter(Boolean).join(" ")
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox"
  }, props)), /*#__PURE__*/React.createElement("span", {
    className: "jsn-check__box"
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "3",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  }))), label || description ? /*#__PURE__*/React.createElement("span", {
    className: "jsn-check__text"
  }, description ? /*#__PURE__*/React.createElement("b", null, label) : label, description) : null);
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.jsn-field{ display:flex; flex-direction:column; gap:6px; font-family:var(--font-sans); }
.jsn-field__label{ font-size:13px; font-weight:600; color:var(--text-strong); letter-spacing:-0.01em; }
.jsn-field__hint{ font-size:12px; color:var(--text-muted); }
.jsn-field__error{ font-size:12px; color:var(--danger-600); }
.jsn-input{
  height:42px; padding:0 13px; font-family:var(--font-sans); font-size:14px; color:var(--text-strong);
  background:#fff; border:1.5px solid var(--border-default); border-radius:var(--radius-md);
  transition:border-color var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast);
  width:100%; box-sizing:border-box;
}
.jsn-input::placeholder{ color:var(--text-subtle); }
.jsn-input:hover{ border-color:var(--border-strong); }
.jsn-input:focus{ outline:none; border-color:var(--navy-500); box-shadow:0 0 0 3px rgba(52,80,96,0.16); }
.jsn-input[aria-invalid="true"]{ border-color:var(--danger-500); }
.jsn-input[aria-invalid="true"]:focus{ box-shadow:0 0 0 3px rgba(217,83,79,0.18); }
.jsn-input[disabled]{ background:var(--gray-100); color:var(--text-muted); cursor:not-allowed; }
.jsn-input--lg{ height:50px; font-size:16px; }
.jsn-input__wrap{ position:relative; display:flex; align-items:center; }
.jsn-input__wrap .jsn-input{ padding-left:38px; }
.jsn-input__lead{ position:absolute; left:12px; display:inline-flex; color:var(--text-muted); width:18px; height:18px; pointer-events:none; }
`;
if (typeof document !== "undefined" && !document.getElementById("jsn-input-css")) {
  const s = document.createElement("style");
  s.id = "jsn-input-css";
  s.textContent = CSS;
  document.head.appendChild(s);
}
function Input({
  label,
  hint,
  error,
  size = "md",
  iconLeft = null,
  id,
  className = "",
  ...props
}) {
  const fieldId = id || (label ? "jsn-" + label.toLowerCase().replace(/\s+/g, "-") : undefined);
  const input = /*#__PURE__*/React.createElement("input", _extends({
    id: fieldId,
    className: ["jsn-input", size === "lg" ? "jsn-input--lg" : "", className].filter(Boolean).join(" "),
    "aria-invalid": error ? "true" : undefined
  }, props));
  return /*#__PURE__*/React.createElement("label", {
    className: "jsn-field",
    htmlFor: fieldId
  }, label ? /*#__PURE__*/React.createElement("span", {
    className: "jsn-field__label"
  }, label) : null, iconLeft ? /*#__PURE__*/React.createElement("span", {
    className: "jsn-input__wrap"
  }, /*#__PURE__*/React.createElement("span", {
    className: "jsn-input__lead"
  }, iconLeft), input) : input, error ? /*#__PURE__*/React.createElement("span", {
    className: "jsn-field__error"
  }, error) : hint ? /*#__PURE__*/React.createElement("span", {
    className: "jsn-field__hint"
  }, hint) : null);
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.jsn-select__wrap{ position:relative; display:inline-flex; width:100%; }
.jsn-select{
  appearance:none; -webkit-appearance:none; width:100%;
  height:42px; padding:0 38px 0 13px; font-family:var(--font-sans); font-size:14px; color:var(--text-strong);
  background:#fff; border:1.5px solid var(--border-default); border-radius:var(--radius-md); cursor:pointer;
  transition:border-color var(--dur-fast), box-shadow var(--dur-fast);
}
.jsn-select:hover{ border-color:var(--border-strong); }
.jsn-select:focus{ outline:none; border-color:var(--navy-500); box-shadow:0 0 0 3px rgba(52,80,96,0.16); }
.jsn-select[disabled]{ background:var(--gray-100); color:var(--text-muted); cursor:not-allowed; }
.jsn-select__chev{ position:absolute; right:13px; top:50%; transform:translateY(-50%); pointer-events:none; color:var(--text-muted); width:16px; height:16px; }
`;
if (typeof document !== "undefined" && !document.getElementById("jsn-select-css")) {
  const s = document.createElement("style");
  s.id = "jsn-select-css";
  s.textContent = CSS;
  document.head.appendChild(s);
}
function Select({
  children,
  options,
  className = "",
  ...props
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "jsn-select__wrap"
  }, /*#__PURE__*/React.createElement("select", _extends({
    className: ["jsn-select", className].filter(Boolean).join(" ")
  }, props), options ? options.map(o => typeof o === "string" ? /*#__PURE__*/React.createElement("option", {
    key: o,
    value: o
  }, o) : /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label)) : children), /*#__PURE__*/React.createElement("svg", {
    className: "jsn-select__chev",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  })));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `
.jsn-switch{ display:inline-flex; align-items:center; gap:10px; font-family:var(--font-sans); cursor:pointer; user-select:none; }
.jsn-switch input{ position:absolute; opacity:0; width:0; height:0; }
.jsn-switch__track{
  width:42px; height:24px; border-radius:999px; background:var(--gray-300); position:relative;
  transition:background var(--dur-base) var(--ease-standard); flex:0 0 auto;
}
.jsn-switch__thumb{
  position:absolute; top:2px; left:2px; width:20px; height:20px; border-radius:50%; background:#fff;
  box-shadow:var(--shadow-sm); transition:transform var(--dur-base) var(--ease-out);
}
.jsn-switch input:checked + .jsn-switch__track{ background:var(--sage-500); }
.jsn-switch input:checked + .jsn-switch__track .jsn-switch__thumb{ transform:translateX(18px); }
.jsn-switch input:focus-visible + .jsn-switch__track{ outline:3px solid var(--focus-ring); outline-offset:2px; }
.jsn-switch input:disabled + .jsn-switch__track{ opacity:.5; }
.jsn-switch__label{ font-size:14px; color:var(--text-body); }
`;
if (typeof document !== "undefined" && !document.getElementById("jsn-switch-css")) {
  const s = document.createElement("style");
  s.id = "jsn-switch-css";
  s.textContent = CSS;
  document.head.appendChild(s);
}
function Switch({
  label,
  className = "",
  ...props
}) {
  return /*#__PURE__*/React.createElement("label", {
    className: ["jsn-switch", className].filter(Boolean).join(" ")
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    role: "switch"
  }, props)), /*#__PURE__*/React.createElement("span", {
    className: "jsn-switch__track"
  }, /*#__PURE__*/React.createElement("span", {
    className: "jsn-switch__thumb"
  })), label ? /*#__PURE__*/React.createElement("span", {
    className: "jsn-switch__label"
  }, label) : null);
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
const CSS = `
.jsn-tabs{ display:inline-flex; gap:2px; font-family:var(--font-sans); }
.jsn-tabs--line{ border-bottom:1px solid var(--border-subtle); gap:4px; display:flex; }
.jsn-tab{
  appearance:none; border:0; background:transparent; cursor:pointer; font-family:inherit;
  font-weight:600; font-size:14px; letter-spacing:-0.01em; color:var(--text-muted);
  padding:10px 16px; border-radius:var(--radius-md); transition:color var(--dur-fast), background var(--dur-fast);
  position:relative;
}
.jsn-tab:hover{ color:var(--text-strong); }
.jsn-tabs--pill .jsn-tab[aria-selected="true"]{ background:var(--navy-500); color:#fff; }
.jsn-tabs--pill{ background:var(--gray-100); padding:4px; border-radius:var(--radius-lg); }
.jsn-tabs--line .jsn-tab{ border-radius:0; padding:12px 4px; margin:0 10px; }
.jsn-tabs--line .jsn-tab[aria-selected="true"]{ color:var(--text-strong); }
.jsn-tabs--line .jsn-tab[aria-selected="true"]::after{
  content:""; position:absolute; left:0; right:0; bottom:-1px; height:2.5px; background:var(--lime-400); border-radius:2px;
}
.jsn-tab__count{ margin-left:7px; font-family:var(--font-mono); font-size:11px; color:var(--text-subtle); }
.jsn-tab[aria-selected="true"] .jsn-tab__count{ color:inherit; opacity:.7; }
`;
if (typeof document !== "undefined" && !document.getElementById("jsn-tabs-css")) {
  const s = document.createElement("style");
  s.id = "jsn-tabs-css";
  s.textContent = CSS;
  document.head.appendChild(s);
}
function Tabs({
  items = [],
  value,
  onChange,
  variant = "line",
  className = ""
}) {
  const [internal, setInternal] = React.useState(value ?? (items[0] && (items[0].value ?? items[0])));
  const active = value !== undefined ? value : internal;
  const select = v => {
    setInternal(v);
    onChange && onChange(v);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: ["jsn-tabs", `jsn-tabs--${variant}`, className].filter(Boolean).join(" "),
    role: "tablist"
  }, items.map(it => {
    const v = it.value ?? it;
    const label = it.label ?? it;
    return /*#__PURE__*/React.createElement("button", {
      key: v,
      role: "tab",
      "aria-selected": active === v,
      className: "jsn-tab",
      onClick: () => select(v)
    }, label, it.count != null ? /*#__PURE__*/React.createElement("span", {
      className: "jsn-tab__count"
    }, it.count) : null);
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/console/console.jsx
try { (() => {
/* Joushen Trust Console — dashboard UI kit */
const {
  Button,
  IconButton,
  Badge,
  Stat,
  Avatar,
  Tabs,
  Input,
  Switch,
  Alert,
  Card
} = window.JoushenDesignSystem_0e80c5;
function Icon({
  name,
  size = 20,
  stroke = 2,
  style
}) {
  return /*#__PURE__*/React.createElement("i", {
    "data-lucide": name,
    style: {
      width: size,
      height: size,
      display: "inline-flex",
      strokeWidth: stroke,
      ...style
    }
  });
}
function relucide() {
  if (window.lucide) window.lucide.createIcons();
}
const NAV = [{
  id: "dashboard",
  label: "Dashboard",
  icon: "layout-dashboard"
}, {
  id: "identities",
  label: "Identities",
  icon: "fingerprint"
}, {
  id: "governance",
  label: "Governance",
  icon: "scale"
}, {
  id: "ot",
  label: "OT Security",
  icon: "cpu"
}, {
  id: "reports",
  label: "Reports",
  icon: "file-text"
}];

/* ============================ LOGIN ============================ */
function Login({
  onAuth
}) {
  React.useEffect(relucide);
  return /*#__PURE__*/React.createElement("div", {
    style: C.loginWrap
  }, /*#__PURE__*/React.createElement("div", {
    style: C.loginNet,
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    style: C.loginGlow,
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    style: C.loginCard
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo/joushen-horizontal-navy.png",
    alt: "Joushen",
    style: {
      height: 30,
      marginBottom: 26
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: ".16em",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      marginBottom: 6
    }
  }, "Trust Console"), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: "600 24px var(--font-sans)",
      letterSpacing: "-.02em",
      color: "var(--text-strong)",
      margin: "0 0 22px"
    }
  }, "Sign in to your workspace"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Work email",
    type: "email",
    defaultValue: "omar.nasser@ncta.gov.sa"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Password",
    type: "password",
    defaultValue: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      margin: "18px 0 22px"
    }
  }, /*#__PURE__*/React.createElement(Switch, {
    label: "Keep me signed in"
  }), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontSize: 13,
      color: "var(--navy-500)",
      fontWeight: 600
    }
  }, "Forgot password?")), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    block: true,
    size: "lg",
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 18
    }),
    onClick: onAuth
  }, "Sign in"), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      marginTop: 18,
      fontSize: 12,
      color: "var(--text-subtle)",
      fontFamily: "var(--font-mono)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "lock-keyhole",
    size: 13,
    style: {
      marginRight: 5,
      verticalAlign: "-2px"
    }
  }), "Hosted in the Kingdom \xB7 PDPL compliant")));
}

/* ============================ SHELL ============================ */
function Sidebar({
  view,
  setView
}) {
  React.useEffect(relucide);
  return /*#__PURE__*/React.createElement("aside", {
    style: C.sidebar
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "22px 20px 18px"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo/joushen-horizontal-lime.png",
    alt: "Joushen",
    style: {
      height: 24
    }
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      padding: "8px 12px",
      flex: 1
    }
  }, NAV.map(n => {
    const active = view === n.id;
    return /*#__PURE__*/React.createElement("button", {
      key: n.id,
      onClick: () => setView(n.id),
      style: {
        ...C.navItem,
        ...(active ? C.navItemActive : {})
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: n.icon,
      size: 19,
      stroke: active ? 2.2 : 1.8
    }), /*#__PURE__*/React.createElement("span", null, n.label), n.id === "governance" && /*#__PURE__*/React.createElement("span", {
      style: C.navBadge
    }, "3"));
  })), /*#__PURE__*/React.createElement("div", {
    style: C.sidebarFoot
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: "Omar Nasser",
    color: "accent",
    size: "sm"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: "#fff",
      fontSize: 13,
      fontWeight: 600,
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, "Omar Nasser"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--navy-300)",
      fontSize: 11
    }
  }, "NCTA \xB7 Admin")), /*#__PURE__*/React.createElement(Icon, {
    name: "settings",
    size: 17,
    style: {
      color: "var(--navy-300)"
    }
  })));
}
function Topbar({
  title,
  onLogout
}) {
  React.useEffect(relucide);
  return /*#__PURE__*/React.createElement("div", {
    style: C.topbar
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 10,
      letterSpacing: ".14em",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, "Trust Console"), /*#__PURE__*/React.createElement("h1", {
    style: {
      font: "600 22px var(--font-sans)",
      letterSpacing: "-.02em",
      color: "var(--text-strong)",
      margin: "2px 0 0"
    }
  }, title)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: C.search
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "search",
    size: 16,
    style: {
      color: "var(--text-subtle)"
    }
  }), /*#__PURE__*/React.createElement("span", null, "Search identities, controls\u2026"), /*#__PURE__*/React.createElement("kbd", {
    style: C.kbd
  }, "\u2318K")), /*#__PURE__*/React.createElement(IconButton, {
    label: "Notifications",
    variant: "outline"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "bell",
    size: 18
  })), /*#__PURE__*/React.createElement(IconButton, {
    label: "Sign out",
    variant: "outline",
    onClick: onLogout
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "log-out",
    size: 18
  }))));
}

/* ============================ DASHBOARD ============================ */
function Dashboard() {
  React.useEffect(relucide);
  const posture = [["Identity", 94, "var(--sage-500)"], ["Governance", 88, "var(--blue-500)"], ["OT Security", 79, "var(--lime-500)"], ["AI Assurance", 71, "var(--navy-400)"]];
  const findings = [["Privileged account without MFA", "Identity", "Critical", "danger"], ["PDPL retention policy expires in 5 days", "Governance", "High", "warning"], ["3 dormant service accounts detected", "Identity", "Medium", "info"], ["OT segment baseline drift", "OT Security", "Medium", "info"]];
  return /*#__PURE__*/React.createElement("div", {
    style: C.viewPad
  }, /*#__PURE__*/React.createElement(Alert, {
    variant: "warning",
    title: "Action required",
    style: {
      marginBottom: 20
    }
  }, "One privileged account is operating without MFA enforcement. ", /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      color: "var(--warning-600)",
      fontWeight: 600
    }
  }, "Review now \u2192")), /*#__PURE__*/React.createElement("div", {
    style: C.dashGrid
  }, /*#__PURE__*/React.createElement(Card, {
    variant: "dark",
    style: {
      display: "flex",
      flexDirection: "column",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: ".14em",
      textTransform: "uppercase",
      color: "var(--lime-400)"
    }
  }, "Organizational trust score"), /*#__PURE__*/React.createElement(Badge, {
    variant: "success",
    dot: true
  }, "+4 this month")), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "700 72px var(--font-sans)",
      letterSpacing: "-.04em",
      color: "#fff",
      lineHeight: 1,
      margin: "14px 0"
    }
  }, "92", /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 30,
      color: "var(--lime-400)"
    }
  }, "/100")), /*#__PURE__*/React.createElement("div", null, posture.map(([k, v, c]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 12,
      marginBottom: 5,
      color: "var(--gray-200)"
    }
  }, /*#__PURE__*/React.createElement("span", null, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)"
    }
  }, v)), /*#__PURE__*/React.createElement("div", {
    style: C.trackDark
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...C.fill,
      width: v + "%",
      background: c
    }
  })))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: C.statRow
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(Stat, {
    label: "Identities",
    value: "1.4M",
    delta: "2.1% MoM",
    trend: "up"
  })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(Stat, {
    label: "MTTD",
    value: "4.2",
    unit: "min",
    delta: "38% faster",
    trend: "up"
  }))), /*#__PURE__*/React.createElement("div", {
    style: C.statRow
  }, /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(Stat, {
    label: "Open findings",
    value: "17",
    delta: "6 closed",
    trend: "up"
  })), /*#__PURE__*/React.createElement(Card, null, /*#__PURE__*/React.createElement(Stat, {
    label: "Controls met",
    value: "318",
    unit: "/342"
  }))), /*#__PURE__*/React.createElement(Card, {
    title: "Recent findings",
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 6
    }
  }, findings.map(([t, area, sev, tone]) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: C.findRow
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "circle-alert",
    size: 17,
    style: {
      color: tone === "danger" ? "var(--danger-500)" : tone === "warning" ? "var(--warning-500)" : "var(--blue-500)",
      flex: "0 0 auto"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text-body)",
      whiteSpace: "nowrap",
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, t)), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      flex: "0 0 auto"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      color: "var(--text-subtle)"
    }
  }, area), /*#__PURE__*/React.createElement(Badge, {
    variant: tone
  }, sev)))))))));
}

/* ============================ IDENTITIES ============================ */
const PEOPLE = [["Layla Al-Otaibi", "Director, Data Office", "Privileged", "sage", "MFA", true], ["Faisal Al-Harbi", "OT Engineer", "Standard", "navy", "MFA", true], ["svc-backup-prod", "Service account", "Service", "blue", "No MFA", false], ["Huda Khalid", "GRC Analyst", "Standard", "navy", "MFA", true], ["Mansour Aziz", "Cloud Admin", "Privileged", "sage", "MFA", true], ["svc-scanner", "Service account", "Service", "blue", "MFA", true]];
function Identities({
  onOpen
}) {
  React.useEffect(relucide);
  const [tab, setTab] = React.useState("all");
  const rows = PEOPLE.filter(p => tab === "all" || tab === "priv" && p[2] === "Privileged" || tab === "svc" && p[2] === "Service");
  return /*#__PURE__*/React.createElement("div", {
    style: C.viewPad
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(Tabs, {
    items: [{
      value: "all",
      label: "All",
      count: PEOPLE.length
    }, {
      value: "priv",
      label: "Privileged",
      count: 2
    }, {
      value: "svc",
      label: "Service",
      count: 2
    }],
    value: tab,
    onChange: setTab,
    variant: "pill"
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "plus",
      size: 16
    })
  }, "Provision identity")), /*#__PURE__*/React.createElement(Card, {
    style: {
      padding: 0,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: C.table
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, ["Identity", "Type", "Authentication", "Status", ""].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: C.th
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, rows.map(p => /*#__PURE__*/React.createElement("tr", {
    key: p[0],
    style: C.tr,
    onClick: () => onOpen(p)
  }, /*#__PURE__*/React.createElement("td", {
    style: C.td
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: p[0].startsWith("svc") ? "S A" : p[0],
    color: p[3],
    size: "sm"
  }), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      fontWeight: 600,
      color: "var(--text-strong)",
      fontSize: 14
    }
  }, p[0]), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text-muted)"
    }
  }, p[1])))), /*#__PURE__*/React.createElement("td", {
    style: C.td
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: p[2] === "Privileged" ? "navy" : "outline"
  }, p[2])), /*#__PURE__*/React.createElement("td", {
    style: C.td
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 7,
      fontSize: 13,
      color: p[5] ? "var(--text-body)" : "var(--danger-600)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: p[5] ? "key-round" : "triangle-alert",
    size: 16
  }), p[4])), /*#__PURE__*/React.createElement("td", {
    style: C.td
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: p[5] ? "success" : "danger",
    dot: true
  }, p[5] ? "Active" : "At risk")), /*#__PURE__*/React.createElement("td", {
    style: {
      ...C.td,
      textAlign: "right"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-right",
    size: 18,
    style: {
      color: "var(--text-subtle)"
    }
  }))))))));
}
function Drawer({
  person,
  onClose
}) {
  React.useEffect(relucide);
  if (!person) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: C.drawerOverlay,
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    style: C.drawer,
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      marginBottom: 22
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: 14,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    name: person[0].startsWith("svc") ? "S A" : person[0],
    color: person[3],
    size: "lg"
  }), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      font: "600 18px var(--font-sans)",
      color: "var(--text-strong)"
    }
  }, person[0]), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: "var(--text-muted)"
    }
  }, person[1]))), /*#__PURE__*/React.createElement(IconButton, {
    label: "Close",
    variant: "ghost",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    size: 20
  }))), !person[5] && /*#__PURE__*/React.createElement(Alert, {
    variant: "danger",
    title: "MFA not enforced",
    style: {
      marginBottom: 18
    }
  }, "Enforce multi-factor authentication to restore this identity's trust standing."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 14,
      marginBottom: 20
    }
  }, [["Type", person[2]], ["Authentication", person[4]], ["Last sign-in", "2h ago · Riyadh"], ["Risk", person[5] ? "Low" : "High"]].map(([k, v]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: C.kv
  }, /*#__PURE__*/React.createElement("div", {
    style: C.kvK
  }, k), /*#__PURE__*/React.createElement("div", {
    style: C.kvV
  }, v)))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: ".12em",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      marginBottom: 10
    }
  }, "Access policies"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8,
      marginBottom: 24
    }
  }, ["Least privilege · enforced", "Just-in-time elevation", "Quarterly access review"].map(x => /*#__PURE__*/React.createElement("div", {
    key: x,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      fontSize: 14,
      color: "var(--text-body)"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "circle-check-big",
    size: 16,
    style: {
      color: "var(--sage-500)"
    }
  }), x))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    block: true,
    iconLeft: /*#__PURE__*/React.createElement(Icon, {
      name: "key-round",
      size: 16
    })
  }, "Enforce MFA"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    block: true
  }, "View activity"))));
}

/* ============================ GOVERNANCE ============================ */
function Governance() {
  React.useEffect(relucide);
  const frameworks = [["NCA ECC", "Essential Cybersecurity Controls", 96, 114, 119], ["SAMA CSF", "Cyber Security Framework", 88, 102, 116], ["PDPL", "Personal Data Protection Law", 79, 41, 52]];
  return /*#__PURE__*/React.createElement("div", {
    style: C.viewPad
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3,1fr)",
      gap: 16,
      marginBottom: 16
    }
  }, frameworks.map(([name, full, pct, met, total]) => /*#__PURE__*/React.createElement(Card, {
    key: name,
    variant: pct >= 90 ? "accent" : "default"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      font: "600 17px var(--font-sans)",
      color: "var(--text-strong)"
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text-muted)"
    }
  }, full)), /*#__PURE__*/React.createElement(Badge, {
    variant: pct >= 90 ? "success" : pct >= 80 ? "info" : "warning"
  }, pct, "%")), /*#__PURE__*/React.createElement("div", {
    style: C.track
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...C.fill,
      width: pct + "%",
      background: pct >= 90 ? "var(--sage-500)" : pct >= 80 ? "var(--blue-500)" : "var(--warning-500)"
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      marginTop: 10,
      fontSize: 12,
      color: "var(--text-muted)",
      fontFamily: "var(--font-mono)"
    }
  }, /*#__PURE__*/React.createElement("span", null, met, "/", total, " controls"), /*#__PURE__*/React.createElement("span", null, total - met, " open"))))), /*#__PURE__*/React.createElement(Card, {
    title: "Control evidence \u2014 collected continuously"
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      ...C.table,
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, ["Control", "Framework", "Owner", "Evidence", "Status"].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: C.th
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, [["Access control policy", "NCA ECC 2-2-1", "Layla A.", "Automated", "success", "Met"], ["Data residency — KSA", "PDPL Art. 29", "Huda K.", "Automated", "success", "Met"], ["Encryption at rest", "SAMA 3.3.9", "Mansour A.", "Manual", "warning", "Review"], ["Incident response plan", "NCA ECC 4-1", "Omar N.", "Automated", "success", "Met"]].map(r => /*#__PURE__*/React.createElement("tr", {
    key: r[0],
    style: C.tr
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      ...C.td,
      fontWeight: 600,
      color: "var(--text-strong)"
    }
  }, r[0]), /*#__PURE__*/React.createElement("td", {
    style: C.td
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      color: "var(--text-muted)"
    }
  }, r[1])), /*#__PURE__*/React.createElement("td", {
    style: C.td
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13
    }
  }, r[2])), /*#__PURE__*/React.createElement("td", {
    style: C.td
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: "outline"
  }, r[3])), /*#__PURE__*/React.createElement("td", {
    style: C.td
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: r[4],
    dot: true
  }, r[5]))))))));
}

/* ============================ PLACEHOLDER VIEW ============================ */
function Placeholder({
  title,
  icon
}) {
  React.useEffect(relucide);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      ...C.viewPad,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      minHeight: 420
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      color: "var(--text-muted)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 64,
      height: 64,
      borderRadius: 14,
      background: "var(--navy-50)",
      color: "var(--navy-500)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      margin: "0 auto 16px"
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 30,
    stroke: 1.6
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "600 18px var(--font-sans)",
      color: "var(--text-strong)",
      marginBottom: 4
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14
    }
  }, "This module follows the same patterns shown in Dashboard, Identities, and Governance.")));
}

/* ============================ ROOT ============================ */
function JoushenConsole() {
  const [authed, setAuthed] = React.useState(false);
  const [view, setView] = React.useState("dashboard");
  const [person, setPerson] = React.useState(null);
  React.useEffect(() => {
    relucide();
  });
  if (!authed) return /*#__PURE__*/React.createElement(Login, {
    onAuth: () => setAuthed(true)
  });
  const titles = {
    dashboard: "Overview",
    identities: "Identities",
    governance: "Governance",
    ot: "OT Security",
    reports: "Reports"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: C.shell
  }, /*#__PURE__*/React.createElement(Sidebar, {
    view: view,
    setView: v => {
      setView(v);
      setPerson(null);
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: C.main
  }, /*#__PURE__*/React.createElement(Topbar, {
    title: titles[view],
    onLogout: () => setAuthed(false)
  }), /*#__PURE__*/React.createElement("div", {
    style: C.scroll
  }, view === "dashboard" && /*#__PURE__*/React.createElement(Dashboard, null), view === "identities" && /*#__PURE__*/React.createElement(Identities, {
    onOpen: setPerson
  }), view === "governance" && /*#__PURE__*/React.createElement(Governance, null), view === "ot" && /*#__PURE__*/React.createElement(Placeholder, {
    title: "OT Security",
    icon: "cpu"
  }), view === "reports" && /*#__PURE__*/React.createElement(Placeholder, {
    title: "Reports",
    icon: "file-text"
  }))), /*#__PURE__*/React.createElement(Drawer, {
    person: person,
    onClose: () => setPerson(null)
  }));
}
window.JoushenConsole = JoushenConsole;

/* ============================ STYLES ============================ */
const C = {
  loginWrap: {
    minHeight: "100vh",
    background: "var(--ink-850)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
    overflow: "hidden",
    padding: 24
  },
  loginNet: {
    position: "absolute",
    inset: 0,
    backgroundImage: "radial-gradient(circle at 1px 1px, rgba(90,180,210,0.12) 1px, transparent 0)",
    backgroundSize: "28px 28px"
  },
  loginGlow: {
    position: "absolute",
    bottom: -160,
    left: -120,
    width: 600,
    height: 600,
    background: "radial-gradient(circle, rgba(205,232,18,0.14), transparent 62%)",
    filter: "blur(20px)"
  },
  loginCard: {
    position: "relative",
    zIndex: 2,
    background: "#fff",
    borderRadius: 16,
    padding: 38,
    width: "min(420px,100%)",
    boxShadow: "0 40px 90px rgba(0,0,0,0.45)",
    borderTop: "3px solid var(--lime-400)"
  },
  shell: {
    display: "flex",
    minHeight: "100vh",
    background: "var(--gray-100)"
  },
  sidebar: {
    width: 248,
    background: "var(--ink-850)",
    display: "flex",
    flexDirection: "column",
    position: "sticky",
    top: 0,
    height: "100vh",
    flex: "0 0 auto"
  },
  navItem: {
    width: "100%",
    display: "flex",
    alignItems: "center",
    gap: 12,
    padding: "11px 14px",
    marginBottom: 2,
    background: "none",
    border: "none",
    borderRadius: 9,
    color: "var(--navy-200)",
    fontSize: 14,
    fontWeight: 500,
    fontFamily: "var(--font-sans)",
    cursor: "pointer",
    textAlign: "left",
    transition: "background .12s, color .12s"
  },
  navItemActive: {
    background: "rgba(205,232,18,0.12)",
    color: "var(--lime-400)",
    fontWeight: 600
  },
  navBadge: {
    marginLeft: "auto",
    background: "var(--danger-500)",
    color: "#fff",
    fontSize: 11,
    fontWeight: 700,
    borderRadius: 999,
    minWidth: 19,
    height: 19,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    padding: "0 5px"
  },
  sidebarFoot: {
    display: "flex",
    alignItems: "center",
    gap: 10,
    padding: "16px 18px",
    borderTop: "1px solid rgba(255,255,255,0.08)"
  },
  main: {
    flex: 1,
    minWidth: 0,
    display: "flex",
    flexDirection: "column"
  },
  topbar: {
    height: 76,
    background: "#fff",
    borderBottom: "1px solid var(--border-subtle)",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "0 28px",
    position: "sticky",
    top: 0,
    zIndex: 20
  },
  search: {
    display: "flex",
    alignItems: "center",
    gap: 9,
    background: "var(--gray-50)",
    border: "1px solid var(--border-subtle)",
    borderRadius: 9,
    padding: "9px 12px",
    color: "var(--text-subtle)",
    fontSize: 13,
    width: 280
  },
  kbd: {
    marginLeft: "auto",
    fontFamily: "var(--font-mono)",
    fontSize: 11,
    background: "#fff",
    border: "1px solid var(--border-subtle)",
    borderRadius: 4,
    padding: "1px 5px"
  },
  scroll: {
    flex: 1,
    overflow: "auto"
  },
  viewPad: {
    padding: 28,
    maxWidth: 1280,
    margin: "0 auto"
  },
  dashGrid: {
    display: "grid",
    gridTemplateColumns: "0.85fr 1.15fr",
    gap: 16,
    alignItems: "stretch"
  },
  statRow: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 16
  },
  findRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
    padding: "11px 0",
    borderTop: "1px solid var(--border-subtle)"
  },
  track: {
    height: 7,
    borderRadius: 4,
    background: "var(--gray-100)",
    overflow: "hidden"
  },
  trackDark: {
    height: 7,
    borderRadius: 4,
    background: "rgba(255,255,255,0.10)",
    overflow: "hidden"
  },
  fill: {
    height: "100%",
    borderRadius: 4
  },
  table: {
    width: "100%",
    borderCollapse: "collapse"
  },
  th: {
    textAlign: "left",
    padding: "13px 18px",
    fontFamily: "var(--font-mono)",
    fontSize: 10,
    letterSpacing: ".1em",
    textTransform: "uppercase",
    color: "var(--text-muted)",
    borderBottom: "1px solid var(--border-subtle)",
    background: "var(--gray-50)"
  },
  tr: {
    cursor: "pointer",
    transition: "background .1s"
  },
  td: {
    padding: "13px 18px",
    borderBottom: "1px solid var(--border-subtle)",
    verticalAlign: "middle"
  },
  drawerOverlay: {
    position: "fixed",
    inset: 0,
    background: "rgba(15,18,22,0.5)",
    backdropFilter: "blur(3px)",
    zIndex: 50,
    display: "flex",
    justifyContent: "flex-end"
  },
  drawer: {
    width: "min(460px,100%)",
    height: "100%",
    background: "#fff",
    padding: 26,
    overflow: "auto",
    boxShadow: "-20px 0 60px rgba(0,0,0,0.3)",
    animation: "jsnSlide .26s var(--ease-out)"
  },
  kv: {
    background: "var(--gray-50)",
    borderRadius: 9,
    padding: "11px 13px"
  },
  kvK: {
    fontFamily: "var(--font-mono)",
    fontSize: 10,
    letterSpacing: ".1em",
    textTransform: "uppercase",
    color: "var(--text-muted)",
    marginBottom: 3
  },
  kvV: {
    fontSize: 14,
    fontWeight: 600,
    color: "var(--text-strong)"
  }
};
if (!document.getElementById("jsn-console-css")) {
  const st = document.createElement("style");
  st.id = "jsn-console-css";
  st.textContent = `
    @keyframes jsnSlide{ from{ transform:translateX(30px); opacity:0; } to{ transform:none; opacity:1; } }
    [style*="cursor: pointer"] tr:hover, tr[style*="cursor: pointer"]:hover{ background:var(--gray-50); }
  `;
  document.head.appendChild(st);
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/console/console.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/website.jsx
try { (() => {
/* Joushen corporate website — UI kit
   Composes DS primitives (Button, Badge, Card, Stat, Input, Select) + Lucide icons. */
const {
  Button,
  Badge,
  Card,
  Stat,
  Input,
  Select
} = window.JoushenDesignSystem_0e80c5;

/* ---- Lucide helper: render an icon by name ---- */
function Icon({
  name,
  size = 20,
  stroke = 2,
  style
}) {
  return /*#__PURE__*/React.createElement("i", {
    "data-lucide": name,
    style: {
      width: size,
      height: size,
      display: "inline-flex",
      strokeWidth: stroke,
      ...style
    }
  });
}
function useLucide(dep) {
  React.useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  });
}
const NAV = ["Platform", "Services", "Industries", "Insights", "Company"];
const SERVICES = [{
  icon: "fingerprint",
  name: "Digital Identity",
  desc: "Identity is the new perimeter. Lifecycle, access governance, and passwordless trust."
}, {
  icon: "compass",
  name: "Cybersecurity Advisory",
  desc: "Strategy, architecture, and roadmaps led by senior advisors — not checklists."
}, {
  icon: "scale",
  name: "Governance, Risk & Compliance",
  desc: "NCA, SAMA CSF, and PDPL alignment with evidence collected continuously."
}, {
  icon: "building-2",
  name: "Critical Infrastructure",
  desc: "Resilience engineering for the systems the Kingdom depends on."
}, {
  icon: "cpu",
  name: "OT Security",
  desc: "Visibility and control across operational technology and industrial networks."
}, {
  icon: "sparkles",
  name: "AI Governance & Security",
  desc: "Govern, secure, and assure AI systems from model to deployment."
}];
const STATS = [{
  label: "Mean time to detect",
  value: "4.2",
  unit: "min"
}, {
  label: "Identities under management",
  value: "1.4M"
}, {
  label: "Frameworks mapped",
  value: "12"
}, {
  label: "Saudi-hosted uptime",
  value: "99.98",
  unit: "%"
}];

/* ============================ HEADER ============================ */
function Header({
  onBrief
}) {
  const [open, setOpen] = React.useState(false);
  useLucide();
  return /*#__PURE__*/React.createElement("header", {
    style: S.header
  }, /*#__PURE__*/React.createElement("div", {
    style: S.headerInner
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      display: "flex",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo/joushen-horizontal-navy.png",
    alt: "Joushen",
    style: {
      height: 30
    }
  })), /*#__PURE__*/React.createElement("nav", {
    style: S.nav,
    className: "jsn-desktop"
  }, NAV.map(n => /*#__PURE__*/React.createElement("a", {
    key: n,
    href: "#",
    style: S.navLink
  }, n, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron-down",
    size: 15,
    style: {
      opacity: .55,
      marginLeft: 4
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: S.headerRight,
    className: "jsn-desktop"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      ...S.navLink,
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "lock-keyhole-open",
    size: 16,
    style: {
      marginRight: 6
    }
  }), "Client login"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "md",
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 16
    }),
    onClick: onBrief
  }, "Request a briefing")), /*#__PURE__*/React.createElement("button", {
    className: "jsn-mobile",
    onClick: () => setOpen(!open),
    style: S.burger,
    "aria-label": "Menu"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: open ? "x" : "menu",
    size: 24
  }))), open && /*#__PURE__*/React.createElement("div", {
    className: "jsn-mobile",
    style: S.mobileMenu
  }, NAV.map(n => /*#__PURE__*/React.createElement("a", {
    key: n,
    href: "#",
    style: S.mobileLink
  }, n)), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    block: true,
    onClick: onBrief
  }, "Request a briefing")));
}

/* ============================ HERO ============================ */
function Hero({
  onBrief
}) {
  useLucide();
  return /*#__PURE__*/React.createElement("section", {
    style: S.hero
  }, /*#__PURE__*/React.createElement("div", {
    style: S.netbg,
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    style: S.heroGlow,
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    style: S.heroInner
  }, /*#__PURE__*/React.createElement("div", {
    style: S.eyebrowLime
  }, "Digital Trust \xB7 Digital Identity"), /*#__PURE__*/React.createElement("h1", {
    style: S.h1
  }, "Identity is the new", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--lime-400)"
    }
  }, "security perimeter.")), /*#__PURE__*/React.createElement("p", {
    style: S.heroSub
  }, "Joushen helps Saudi organizations secure identities, strengthen governance, and protect critical infrastructure \u2014 built for local regulation, hosted in the Kingdom, aligned with Vision 2030."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 18
    }),
    onClick: onBrief
  }, "Request a briefing"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "lg",
    className: "jsn-hero-ghost"
  }, "Explore the platform")), /*#__PURE__*/React.createElement("div", {
    style: S.frameworks
  }, /*#__PURE__*/React.createElement("span", {
    style: S.fwLabel
  }, "Aligned with"), ["NCA ECC", "SAMA CSF", "PDPL", "Vision 2030"].map(f => /*#__PURE__*/React.createElement("span", {
    key: f,
    style: S.fwChip
  }, f)))), /*#__PURE__*/React.createElement(FloatingPanel, null));
}
function FloatingPanel() {
  useLucide();
  const rows = [{
    k: "Privileged access",
    v: "Enforced",
    ok: true
  }, {
    k: "Identity posture",
    v: "94 / 100",
    ok: true
  }, {
    k: "PDPL controls",
    v: "3 due",
    ok: false
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: S.panel
  }, /*#__PURE__*/React.createElement("div", {
    style: S.panelHead
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: ".14em",
      textTransform: "uppercase",
      color: "var(--navy-300)"
    }
  }, "Trust Console"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      color: "var(--lime-400)",
      fontSize: 12,
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: "50%",
      background: "var(--lime-400)"
    }
  }), "Live")), rows.map(r => /*#__PURE__*/React.createElement("div", {
    key: r.k,
    style: S.panelRow
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: r.ok ? "circle-check-big" : "circle-alert",
    size: 18,
    style: {
      color: r.ok ? "var(--sage-500)" : "var(--warning-500)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--gray-200)",
      fontSize: 14
    }
  }, r.k)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 13,
      color: r.ok ? "#fff" : "var(--warning-500)"
    }
  }, r.v))), /*#__PURE__*/React.createElement("div", {
    style: S.panelFoot
  }, /*#__PURE__*/React.createElement(Stat, {
    label: "Mean time to detect",
    value: "4.2",
    unit: "min",
    tone: "dark"
  })));
}

/* ============================ SERVICES ============================ */
function Services() {
  useLucide();
  return /*#__PURE__*/React.createElement("section", {
    style: S.section
  }, /*#__PURE__*/React.createElement("div", {
    style: S.container
  }, /*#__PURE__*/React.createElement(SectionHead, {
    eyebrow: "What we do",
    title: "Specialized advisory and managed services",
    sub: "Seven focused practices, one accountable partner \u2014 from boardroom strategy to 24/7 operations."
  }), /*#__PURE__*/React.createElement("div", {
    style: S.serviceGrid
  }, SERVICES.map((s, i) => /*#__PURE__*/React.createElement(Card, {
    key: s.name,
    variant: i === 0 ? "accent" : "default",
    interactive: true,
    className: "jsn-svc"
  }, /*#__PURE__*/React.createElement("div", {
    style: S.svcIcon
  }, /*#__PURE__*/React.createElement(Icon, {
    name: s.icon,
    size: 24,
    stroke: 1.75
  })), /*#__PURE__*/React.createElement("h3", {
    style: {
      font: "600 18px var(--font-sans)",
      letterSpacing: "-.015em",
      color: "var(--text-strong)",
      margin: "0 0 8px"
    }
  }, s.name), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 14,
      lineHeight: 1.6,
      color: "var(--text-muted)"
    }
  }, s.desc), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: S.svcLink
  }, "Learn more ", /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-right",
    size: 15
  })))))));
}

/* ============================ PLATFORM ============================ */
function Platform() {
  useLucide();
  const feats = [{
    icon: "radar",
    t: "Continuous assurance",
    d: "Evidence collected automatically and mapped to every framework you answer to."
  }, {
    icon: "git-branch",
    t: "Identity lifecycle",
    d: "Joiner-mover-leaver automation with least-privilege enforced by default."
  }, {
    icon: "activity",
    t: "Unified posture",
    d: "One trust score across identity, GRC, and operational technology."
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      ...S.section,
      background: "var(--ink-850)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: S.netbgSubtle,
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      ...S.container,
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: S.platformGrid
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: S.eyebrowLime
  }, "The platform"), /*#__PURE__*/React.createElement("h2", {
    style: {
      ...S.h2,
      color: "#fff"
    }
  }, "Trust, embedded from strategy to execution."), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--gray-300)",
      fontSize: 17,
      lineHeight: 1.65,
      margin: "0 0 28px",
      maxWidth: 460
    }
  }, "The Joushen Trust Console unifies digital identity, governance, and OT security into a single operating picture \u2014 so leadership sees risk in business terms, not log lines."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, feats.map(f => /*#__PURE__*/React.createElement("div", {
    key: f.t,
    style: {
      display: "flex",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: S.featIcon
  }, /*#__PURE__*/React.createElement(Icon, {
    name: f.icon,
    size: 20,
    stroke: 1.75
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      color: "#fff",
      fontWeight: 600,
      fontSize: 15,
      marginBottom: 2
    }
  }, f.t), /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--navy-200)",
      fontSize: 14,
      lineHeight: 1.55
    }
  }, f.d))))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 30
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 16
    })
  }, "See the Trust Console"))), /*#__PURE__*/React.createElement(ConsoleMock, null))));
}
function ConsoleMock() {
  useLucide();
  return /*#__PURE__*/React.createElement("div", {
    style: S.mock
  }, /*#__PURE__*/React.createElement("div", {
    style: S.mockBar
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("i", {
    style: S.dot
  }), /*#__PURE__*/React.createElement("i", {
    style: S.dot
  }), /*#__PURE__*/React.createElement("i", {
    style: S.dot
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      color: "var(--navy-300)"
    }
  }, "console.joushen.sa")), /*#__PURE__*/React.createElement("div", {
    style: S.mockBody
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "baseline",
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 10,
      letterSpacing: ".14em",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, "Organizational trust score"), /*#__PURE__*/React.createElement("div", {
    style: {
      font: "700 46px var(--font-sans)",
      letterSpacing: "-.03em",
      color: "var(--text-strong)"
    }
  }, "92", /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 22,
      color: "var(--lime-500)"
    }
  }, "/100"))), /*#__PURE__*/React.createElement(Badge, {
    variant: "success",
    dot: true
  }, "Improving")), /*#__PURE__*/React.createElement("div", {
    style: S.barRow
  }, [["Identity", 94, "var(--sage-500)"], ["Governance", 88, "var(--blue-500)"], ["OT Security", 79, "var(--lime-500)"], ["AI Assurance", 71, "var(--navy-400)"]].map(([k, v, c]) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 12,
      marginBottom: 5,
      color: "var(--text-body)"
    }
  }, /*#__PURE__*/React.createElement("span", null, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)"
    }
  }, v)), /*#__PURE__*/React.createElement("div", {
    style: S.track
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...S.fill,
      width: v + "%",
      background: c
    }
  })))))));
}

/* ============================ STATS BAND ============================ */
function StatsBand() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--navy-500)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...S.container,
      display: "grid",
      gridTemplateColumns: "repeat(4,1fr)",
      gap: 24,
      padding: "56px 32px"
    },
    className: "jsn-stats"
  }, STATS.map(s => /*#__PURE__*/React.createElement("div", {
    key: s.label
  }, /*#__PURE__*/React.createElement(Stat, {
    label: s.label,
    value: s.value,
    unit: s.unit,
    tone: "dark"
  })))));
}

/* ============================ CTA ============================ */
function CTA({
  onBrief
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: S.section
  }, /*#__PURE__*/React.createElement("div", {
    style: S.container
  }, /*#__PURE__*/React.createElement("div", {
    style: S.cta
  }, /*#__PURE__*/React.createElement("div", {
    style: S.netbgSubtle,
    "aria-hidden": "true"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      maxWidth: 620
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: S.eyebrowLime
  }, "Trust beyond compliance"), /*#__PURE__*/React.createElement("h2", {
    style: {
      ...S.h2,
      color: "#fff",
      marginBottom: 14
    }
  }, "Securing the future of digital Saudi Arabia."), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--gray-300)",
      fontSize: 17,
      lineHeight: 1.6,
      margin: "0 0 26px"
    }
  }, "Book a 45-minute executive briefing. We'll map your identity and trust posture against the frameworks that matter \u2014 and where to invest next."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 18
    }),
    onClick: onBrief
  }, "Request a briefing"), /*#__PURE__*/React.createElement(Button, {
    variant: "outline",
    size: "lg",
    className: "jsn-hero-ghost"
  }, "Download capabilities"))))));
}

/* ============================ FOOTER ============================ */
function Footer() {
  const cols = [["Platform", ["Trust Console", "Digital Identity", "GRC", "OT Security"]], ["Services", ["Advisory", "Managed Services", "Assurance", "Awareness"]], ["Company", ["About Joushen", "Vision 2030", "Careers", "Contact"]]];
  return /*#__PURE__*/React.createElement("footer", {
    style: S.footer
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...S.container,
      paddingTop: 56,
      paddingBottom: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: S.footerGrid
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 300
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo/joushen-horizontal-white.png",
    alt: "Joushen",
    style: {
      height: 26,
      marginBottom: 16
    }
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--navy-200)",
      fontSize: 14,
      lineHeight: 1.6,
      margin: 0
    }
  }, "Empowering trust. Enabling digital transformation. A Saudi cybersecurity and digital-trust company.")), cols.map(([h, items]) => /*#__PURE__*/React.createElement("div", {
    key: h
  }, /*#__PURE__*/React.createElement("div", {
    style: S.footHead
  }, h), items.map(i => /*#__PURE__*/React.createElement("a", {
    key: i,
    href: "#",
    style: S.footLink
  }, i))))), /*#__PURE__*/React.createElement("div", {
    style: S.footerBottom
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 2026 Joushen. Hosted in the Kingdom of Saudi Arabia."), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: 18
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: S.footLink
  }, "Privacy (PDPL)"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: S.footLink
  }, "Terms"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: S.footLink
  }, "\u0627\u0644\u0639\u0631\u0628\u064A\u0629")))));
}

/* ============================ BRIEFING MODAL ============================ */
function BriefingModal({
  open,
  onClose
}) {
  if (!open) return null;
  return /*#__PURE__*/React.createElement("div", {
    style: S.overlay,
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    style: S.modal,
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: ".14em",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, "Executive briefing"), /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: "4px 0 0",
      font: "600 22px var(--font-sans)",
      letterSpacing: "-.015em",
      color: "var(--text-strong)"
    }
  }, "Request a briefing")), /*#__PURE__*/React.createElement("button", {
    onClick: onClose,
    style: S.modalClose,
    "aria-label": "Close"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    size: 20
  }))), /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--text-muted)",
      fontSize: 14,
      margin: "0 0 20px"
    }
  }, "A senior advisor will reach out within one business day."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Full name",
    placeholder: "Your name"
  }), /*#__PURE__*/React.createElement(Input, {
    label: "Work email",
    type: "email",
    placeholder: "name@org.gov.sa"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 16,
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "Organization",
    placeholder: "Entity name"
  }), /*#__PURE__*/React.createElement("label", {
    className: "jsn-field",
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text-strong)"
    }
  }, "Area of interest"), /*#__PURE__*/React.createElement(Select, {
    options: ["Digital Identity", "GRC", "OT Security", "AI Governance"]
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 24,
      display: "flex",
      justifyContent: "flex-end",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: onClose
  }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    iconRight: /*#__PURE__*/React.createElement(Icon, {
      name: "arrow-right",
      size: 16
    }),
    onClick: onClose
  }, "Submit request"))));
}

/* ============================ SHARED ============================ */
function SectionHead({
  eyebrow,
  title,
  sub
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 640,
      marginBottom: 44
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 12,
      letterSpacing: ".16em",
      textTransform: "uppercase",
      color: "var(--sage-500)",
      marginBottom: 12
    }
  }, eyebrow), /*#__PURE__*/React.createElement("h2", {
    style: S.h2
  }, title), sub && /*#__PURE__*/React.createElement("p", {
    style: {
      color: "var(--text-muted)",
      fontSize: 17,
      lineHeight: 1.6,
      margin: "14px 0 0"
    }
  }, sub));
}
function JoushenSite() {
  const [brief, setBrief] = React.useState(false);
  React.useEffect(() => {
    if (window.lucide) window.lucide.createIcons();
  }, [brief]);
  const onBrief = () => setBrief(true);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Header, {
    onBrief: onBrief
  }), /*#__PURE__*/React.createElement(Hero, {
    onBrief: onBrief
  }), /*#__PURE__*/React.createElement(Services, null), /*#__PURE__*/React.createElement(Platform, null), /*#__PURE__*/React.createElement(StatsBand, null), /*#__PURE__*/React.createElement(CTA, {
    onBrief: onBrief
  }), /*#__PURE__*/React.createElement(Footer, null), /*#__PURE__*/React.createElement(BriefingModal, {
    open: brief,
    onClose: () => setBrief(false)
  }));
}
window.JoushenSite = JoushenSite;

/* ============================ STYLES ============================ */
const S = {
  header: {
    position: "sticky",
    top: 0,
    zIndex: 40,
    background: "rgba(255,255,255,0.9)",
    backdropFilter: "blur(12px)",
    borderBottom: "1px solid var(--border-subtle)"
  },
  headerInner: {
    maxWidth: 1320,
    margin: "0 auto",
    padding: "0 32px",
    height: 70,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between"
  },
  nav: {
    display: "flex",
    gap: 28
  },
  navLink: {
    display: "inline-flex",
    alignItems: "center",
    color: "var(--navy-700)",
    fontSize: 14,
    fontWeight: 500,
    textDecoration: "none"
  },
  headerRight: {
    display: "flex",
    alignItems: "center",
    gap: 18
  },
  burger: {
    background: "none",
    border: "none",
    color: "var(--navy-700)",
    cursor: "pointer",
    display: "none",
    padding: 6
  },
  mobileMenu: {
    display: "flex",
    flexDirection: "column",
    gap: 10,
    padding: "16px 32px 22px",
    borderTop: "1px solid var(--border-subtle)",
    background: "#fff"
  },
  mobileLink: {
    color: "var(--navy-700)",
    fontSize: 16,
    fontWeight: 500,
    textDecoration: "none",
    padding: "8px 0"
  },
  hero: {
    position: "relative",
    background: "var(--ink-850)",
    overflow: "hidden",
    padding: "92px 32px 100px"
  },
  heroInner: {
    position: "relative",
    maxWidth: 1320,
    margin: "0 auto",
    zIndex: 2
  },
  netbg: {
    position: "absolute",
    inset: 0,
    backgroundImage: "radial-gradient(circle at 1px 1px, rgba(90,180,210,0.12) 1px, transparent 0)",
    backgroundSize: "26px 26px",
    opacity: .8
  },
  netbgSubtle: {
    position: "absolute",
    inset: 0,
    backgroundImage: "radial-gradient(circle at 1px 1px, rgba(205,232,18,0.08) 1px, transparent 0)",
    backgroundSize: "30px 30px"
  },
  heroGlow: {
    position: "absolute",
    top: -120,
    right: -80,
    width: 560,
    height: 560,
    background: "radial-gradient(circle, rgba(205,232,18,0.16), transparent 62%)",
    filter: "blur(20px)",
    zIndex: 1
  },
  eyebrowLime: {
    fontFamily: "var(--font-mono)",
    fontSize: 12,
    letterSpacing: ".18em",
    textTransform: "uppercase",
    color: "var(--lime-400)",
    marginBottom: 18
  },
  h1: {
    font: "700 66px/1.02 var(--font-sans)",
    letterSpacing: "-.03em",
    color: "#fff",
    margin: "0 0 22px",
    maxWidth: 760
  },
  heroSub: {
    color: "var(--gray-300)",
    fontSize: 19,
    lineHeight: 1.6,
    maxWidth: 540,
    margin: "0 0 32px"
  },
  frameworks: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    marginTop: 46,
    flexWrap: "wrap"
  },
  fwLabel: {
    fontFamily: "var(--font-mono)",
    fontSize: 11,
    letterSpacing: ".12em",
    textTransform: "uppercase",
    color: "var(--navy-300)"
  },
  fwChip: {
    padding: "6px 12px",
    border: "1px solid rgba(255,255,255,0.14)",
    borderRadius: 6,
    color: "var(--gray-200)",
    fontSize: 13,
    fontWeight: 500
  },
  panel: {
    position: "absolute",
    right: "max(32px, calc(50% - 660px + 32px))",
    top: 120,
    width: 340,
    background: "rgba(29,36,43,0.86)",
    backdropFilter: "blur(8px)",
    border: "1px solid rgba(255,255,255,0.10)",
    borderRadius: 14,
    padding: 18,
    zIndex: 3,
    boxShadow: "0 30px 60px rgba(0,0,0,0.4)"
  },
  panelHead: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 14,
    paddingBottom: 14,
    borderBottom: "1px solid rgba(255,255,255,0.08)"
  },
  panelRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    padding: "9px 0"
  },
  panelFoot: {
    marginTop: 12,
    paddingTop: 14,
    borderTop: "1px solid rgba(255,255,255,0.08)"
  },
  section: {
    padding: "96px 32px",
    position: "relative",
    overflow: "hidden"
  },
  container: {
    maxWidth: 1320,
    margin: "0 auto",
    position: "relative"
  },
  h2: {
    font: "600 40px/1.1 var(--font-sans)",
    letterSpacing: "-.02em",
    color: "var(--text-strong)",
    margin: 0
  },
  serviceGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(3,1fr)",
    gap: 20
  },
  svcIcon: {
    width: 48,
    height: 48,
    borderRadius: 10,
    background: "var(--navy-50)",
    color: "var(--navy-600)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 18
  },
  svcLink: {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    marginTop: 16,
    color: "var(--navy-500)",
    fontSize: 14,
    fontWeight: 600,
    textDecoration: "none"
  },
  platformGrid: {
    display: "grid",
    gridTemplateColumns: "1fr 1fr",
    gap: 64,
    alignItems: "center"
  },
  featIcon: {
    flex: "0 0 auto",
    width: 40,
    height: 40,
    borderRadius: 9,
    background: "rgba(205,232,18,0.12)",
    color: "var(--lime-400)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center"
  },
  mock: {
    background: "#fff",
    borderRadius: 14,
    boxShadow: "0 40px 80px rgba(0,0,0,0.4)",
    overflow: "hidden",
    border: "1px solid rgba(255,255,255,0.08)"
  },
  mockBar: {
    height: 38,
    background: "var(--gray-50)",
    borderBottom: "1px solid var(--border-subtle)",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    padding: "0 14px"
  },
  dot: {
    width: 9,
    height: 9,
    borderRadius: "50%",
    background: "var(--gray-300)",
    display: "inline-block"
  },
  mockBody: {
    padding: 24
  },
  barRow: {
    marginTop: 6
  },
  track: {
    height: 7,
    borderRadius: 4,
    background: "var(--gray-100)",
    overflow: "hidden"
  },
  fill: {
    height: "100%",
    borderRadius: 4
  },
  cta: {
    position: "relative",
    overflow: "hidden",
    background: "var(--navy-600)",
    borderRadius: 24,
    padding: "64px 56px",
    borderTop: "3px solid var(--lime-400)"
  },
  footer: {
    background: "var(--ink-850)"
  },
  footerGrid: {
    display: "grid",
    gridTemplateColumns: "1.4fr 1fr 1fr 1fr",
    gap: 40
  },
  footHead: {
    color: "#fff",
    fontSize: 13,
    fontWeight: 600,
    marginBottom: 14,
    letterSpacing: ".02em"
  },
  footLink: {
    display: "block",
    color: "var(--navy-200)",
    fontSize: 14,
    textDecoration: "none",
    padding: "6px 0"
  },
  footerBottom: {
    marginTop: 44,
    paddingTop: 22,
    borderTop: "1px solid rgba(255,255,255,0.08)",
    display: "flex",
    justifyContent: "space-between",
    color: "var(--navy-300)",
    fontSize: 13,
    flexWrap: "wrap",
    gap: 12
  },
  overlay: {
    position: "fixed",
    inset: 0,
    background: "rgba(15,18,22,0.6)",
    backdropFilter: "blur(4px)",
    zIndex: 60,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: 24
  },
  modal: {
    background: "#fff",
    borderRadius: 16,
    padding: 30,
    width: "min(560px,100%)",
    boxShadow: "var(--shadow-xl)",
    borderTop: "3px solid var(--lime-400)"
  },
  modalClose: {
    background: "var(--gray-100)",
    border: "none",
    borderRadius: 8,
    width: 34,
    height: 34,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    color: "var(--text-body)"
  }
};

/* responsive helpers injected once */
if (!document.getElementById("jsn-site-css")) {
  const st = document.createElement("style");
  st.id = "jsn-site-css";
  st.textContent = `
    .jsn-mobile{ display:none; }
    .jsn-hero-ghost{ color:#fff !important; border-color:rgba(255,255,255,0.25) !important; background:transparent !important; }
    .jsn-hero-ghost:hover{ background:rgba(255,255,255,0.08) !important; }
    @media (max-width: 1080px){
      .jsn-desktop{ display:none !important; }
      .jsn-mobile{ display:flex !important; }
      [style*="grid-template-columns: 1fr 1fr"]{ }
    }
    @media (max-width: 920px){
      .jsn-svc{ }
    }
  `;
  document.head.appendChild(st);
}
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/website.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Stat = __ds_scope.Stat;

__ds_ns.Alert = __ds_scope.Alert;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
